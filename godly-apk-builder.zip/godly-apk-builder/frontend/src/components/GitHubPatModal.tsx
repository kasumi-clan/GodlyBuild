import React, { useState, useEffect } from 'react';
import { Github, KeyRound, CheckCircle2, XCircle, RefreshCw, Trash2, Plus, X, Shield } from 'lucide-react';
import { apiRequest } from '../services/api';
import { GitHubConnectionInfo } from '../types';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  githubInfo: GitHubConnectionInfo;
  onUpdated: () => void;
}

export const GitHubPatModal: React.FC<Props> = ({ isOpen, onClose, githubInfo, onUpdated }) => {
  const [githubUsername, setGithubUsername] = useState(githubInfo.github_username || '');
  const [pat, setPat] = useState('');
  const [repos, setRepos] = useState<Array<{ name: string; full_name: string; private: boolean }>>([]);
  const [selectedRepo, setSelectedRepo] = useState(githubInfo.selected_repo_full_name || '');
  const [newRepoName, setNewRepoName] = useState('godly-apk-workspace');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen && githubInfo.status === 'CONNECTED') {
      setGithubUsername(githubInfo.github_username || '');
      setSelectedRepo(githubInfo.selected_repo_full_name || '');
      loadRepositories();
    }
  }, [isOpen, githubInfo.status]);

  if (!isOpen) return null;

  const loadRepositories = async () => {
    try {
      const data = await apiRequest('/api/github/repositories');
      setRepos(data.repositories || []);
      if (data.selected_repo_full_name) {
        setSelectedRepo(data.selected_repo_full_name);
      }
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleConnect = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setSuccess(null);
    try {
      await apiRequest('/api/github/connect', {
        method: 'POST',
        body: JSON.stringify({
          github_username: githubUsername.trim(),
          personal_access_token: pat.trim(),
          selected_repo_full_name: selectedRepo || undefined
        })
      });
      setPat(''); // Clear plaintext token from frontend state immediately
      setSuccess('Đã kết nối và mã hóa AES-256-GCM cho GitHub Token thành công!');
      onUpdated();
      await loadRepositories();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDisconnect = async () => {
    setLoading(true);
    setError(null);
    try {
      await apiRequest('/api/github/disconnect', { method: 'DELETE' });
      setPat('');
      setRepos([]);
      setSuccess('Đã ngắt kết nối và xóa GitHub Token.');
      onUpdated();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateRepo = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await apiRequest('/api/github/repositories/create', {
        method: 'POST',
        body: JSON.stringify({ repo_name: newRepoName, private: true })
      });
      setSelectedRepo(res.repository.full_name);
      setSuccess(`Đã tạo và chọn Private Repository: ${res.repository.full_name}`);
      onUpdated();
      await loadRepositories();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleSelectRepo = async (fullName: string) => {
    setSelectedRepo(fullName);
    try {
      await apiRequest('/api/github/repositories/select', {
        method: 'POST',
        body: JSON.stringify({ full_name: fullName })
      });
      setSuccess(`Đã chọn Repository: ${fullName}`);
      onUpdated();
    } catch (err: any) {
      setError(err.message);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#0B1F44]/60 flex items-center justify-center p-4">
      <div className="bg-white border border-[#D8E3F3] rounded-3xl max-w-lg w-full p-6 sm:p-7 shadow-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-[#EAF2FF] flex items-center justify-center text-[#2563EB]">
              <Github className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-[#10213A]">Kết nối GitHub Personal Access Token</h2>
              <p className="text-xs text-[#64748B]">Bảo mật AES-256-GCM · Least Privilege</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg text-[#64748B] hover:bg-[#F5F8FF]">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Status Banner */}
        <div className="mb-5 p-3.5 rounded-2xl bg-[#F5F8FF] border border-[#D8E3F3] flex items-center justify-between">
          <div className="flex items-center gap-3">
            {githubInfo.status === 'CONNECTED' ? (
              <>
                {githubInfo.avatar_url && (
                  <img src={githubInfo.avatar_url} alt="avatar" className="w-9 h-9 rounded-full border border-[#D8E3F3]" />
                )}
                <div>
                  <div className="flex items-center gap-1.5 text-sm font-bold text-[#10213A]">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    Connected: @{githubInfo.github_username}
                  </div>
                  <div className="text-xs font-mono text-[#64748B]">
                    Token: {githubInfo.masked_pat}
                  </div>
                </div>
              </>
            ) : (
              <div className="flex items-center gap-2 text-sm font-semibold text-[#64748B]">
                <XCircle className="w-4 h-4 text-amber-500" />
                Trạng thái: Disconnected (Chưa kết nối)
              </div>
            )}
          </div>
          {githubInfo.status === 'CONNECTED' && (
            <button
              type="button"
              onClick={handleDisconnect}
              disabled={loading}
              className="px-3 py-1.5 rounded-xl bg-red-50 hover:bg-red-100 text-red-600 text-xs font-semibold flex items-center gap-1"
            >
              <Trash2 className="w-3.5 h-3.5" />
              Disconnect
            </button>
          )}
        </div>

        {error && (
          <div className="mb-4 p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs font-medium">
            {error}
          </div>
        )}
        {success && (
          <div className="mb-4 p-3 rounded-xl bg-[#EAF2FF] border border-[#D8E3F3] text-[#123A73] text-xs font-medium">
            {success}
          </div>
        )}

        <form onSubmit={handleConnect} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-[#64748B] mb-1">
              GitHub Username
            </label>
            <input
              type="text"
              required
              value={githubUsername}
              onChange={(e) => setGithubUsername(e.target.value)}
              placeholder="Nhập đúng username GitHub của bạn"
              className="w-full px-3.5 py-2.5 rounded-xl border border-[#D8E3F3] text-sm focus:outline-none focus:border-[#2563EB]"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#64748B] mb-1">
              Personal Access Token (Classic hoặc Fine-grained)
            </label>
            <input
              type="password"
              required
              value={pat}
              onChange={(e) => setPat(e.target.value)}
              placeholder="ghp_... hoặc github_pat_..."
              className="w-full px-3.5 py-2.5 rounded-xl border border-[#D8E3F3] text-sm font-mono focus:outline-none focus:border-[#2563EB]"
            />
            <p className="text-[11px] text-[#64748B] mt-1">
              Token chỉ hiển thị dạng ẩn và không bao giờ lưu ở localStorage hay hiển thị lại.
            </p>
          </div>

          <div className="flex flex-wrap gap-2">
            <button
              type="submit"
              disabled={loading}
              className="flex-1 py-2.5 px-4 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white text-xs font-bold flex items-center justify-center gap-1.5"
            >
              <KeyRound className="w-3.5 h-3.5" />
              {githubInfo.status === 'CONNECTED' ? 'Reconnect / Switch Account' : 'Connect GitHub'}
            </button>
          </div>
        </form>

        {/* Repository Selection / Auto-Create Private Repository */}
        {githubInfo.status === 'CONNECTED' && (
          <div className="mt-6 pt-5 border-t border-[#D8E3F3] space-y-3">
            <label className="block text-xs font-bold uppercase tracking-wider text-[#10213A]">
              Repository Build Workspace (Thuộc @{githubInfo.github_username})
            </label>
            <select
              value={selectedRepo}
              onChange={(e) => handleSelectRepo(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-[#D8E3F3] bg-[#F5F8FF] text-sm"
            >
              <option value="">-- Chọn Repository để chạy GitHub Actions --</option>
              {repos.map((r) => (
                <option key={r.full_name} value={r.full_name}>
                  {r.full_name} ({r.private ? 'Private' : 'Public'})
                </option>
              ))}
            </select>

            <div className="flex gap-2 pt-1">
              <input
                type="text"
                value={newRepoName}
                onChange={(e) => setNewRepoName(e.target.value)}
                placeholder="Tên private repo mới"
                className="flex-1 px-3 py-2 rounded-xl border border-[#D8E3F3] text-xs"
              />
              <button
                type="button"
                onClick={handleCreateRepo}
                disabled={loading}
                className="px-3.5 py-2 rounded-xl bg-[#123A73] hover:bg-[#0B1F44] text-white text-xs font-semibold flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" />
                Tạo Private Repo
              </button>
            </div>
          </div>
        )}

        <div className="mt-5 p-3.5 rounded-2xl bg-[#EAF2FF]/70 border border-[#D8E3F3] text-xs text-[#123A73] space-y-1">
          <div className="font-bold flex items-center gap-1.5">
            <Shield className="w-3.5 h-3.5 text-[#2563EB]" />
            Hướng dẫn tạo PAT an toàn (Quyền tối thiểu):
          </div>
          <p>1. Vào GitHub Settings → Developer settings → Personal access tokens.</p>
          <p>2. Với Classic PAT: Chỉ bật quyền <strong>repo</strong> và <strong>workflow</strong>.</p>
          <p>3. Với Fine-grained PAT: Cấp quyền <strong>Contents (Read & Write)</strong> và <strong>Actions (Read & Write)</strong>.</p>
        </div>
      </div>
    </div>
  );
};
