import React, { useState } from 'react';
import { Eye, EyeOff, Lock, User, Mail, ShieldCheck, Github, KeyRound } from 'lucide-react';
import { apiRequest, setCsrfToken } from '../services/api';

interface AuthScreenProps {
  onLoginSuccess: () => void;
}

export const AuthScreen: React.FC<AuthScreenProps> = ({ onLoginSuccess }) => {
  const [mode, setMode] = useState<'login' | 'register' | 'forgot'>('login');
  const [identifier, setIdentifier] = useState('');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(false);
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showPatGuide, setShowPatGuide] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setNotice(null);
    setLoading(true);
    try {
      if (mode === 'login') {
        const res = await apiRequest('/api/auth/login', {
          method: 'POST',
          body: JSON.stringify({ identifier, password, remember_me: rememberMe })
        });
        if (res.csrf_token) {
          setCsrfToken(res.csrf_token);
        }
        onLoginSuccess();
      } else if (mode === 'register') {
        await apiRequest('/api/auth/register', {
          method: 'POST',
          body: JSON.stringify({
            username,
            email,
            password,
            confirm_password: confirmPassword,
            terms_accepted: termsAccepted
          })
        });
        setNotice('Đăng ký thành công! Vui lòng đăng nhập.');
        setMode('login');
        setIdentifier(username);
        setPassword('');
      } else if (mode === 'forgot') {
        const res = await apiRequest('/api/auth/forgot-password', {
          method: 'POST',
          body: JSON.stringify({ email })
        });
        setNotice(res.message);
      }
    } catch (err: any) {
      setError(err.message || 'Có lỗi xảy ra.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F5F8FF] flex flex-col justify-center items-center px-4 py-8">
      <div className="w-full max-w-md bg-[#FFFFFF] border border-[#D8E3F3] rounded-3xl shadow-[0_14px_40px_rgba(18,58,115,0.08)] p-7 sm:p-9">
        {/* Android White Logo on Blue Icon Background */}
        <div className="flex flex-col items-center text-center mb-7">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#2563EB] to-[#123A73] flex items-center justify-center shadow-md mb-4">
            <svg className="w-9 h-9 text-white" viewBox="0 0 24 24" fill="currentColor">
              <path d="M17.523 15.3414c-.5511 0-.9993-.4486-.9993-.9997s.4482-.9993.9993-.9993c.5511 0 .9993.4482.9993.9993.0001.5511-.4482.9997-.9993.9997m-11.046 0c-.5511 0-.9993-.4486-.9993-.9997s.4482-.9993.9993-.9993c.5511 0 .9993.4482.9993.9993 0 .5511-.4482.9997-.9993.9997m11.4045-6.02l1.9973-3.4592a.416.416 0 00-.1521-.5676.416.416 0 00-.5676.1521l-2.0223 3.503C15.5902 8.2439 13.8533 7.8508 12 7.8508s-3.5902.3931-5.1367 1.0989L4.841 5.4467a.4161.4161 0 00-.5677-.1521.4157.4157 0 00-.1521.5676l1.9973 3.4592C2.6889 11.1867.3432 14.6589 0 18.761h24c-.3435-4.1021-2.6892-7.5743-6.1185-9.4396" />
            </svg>
          </div>
          <h1 className="text-2xl font-extrabold tracking-tight text-[#10213A]">
            Godly APK Builder
          </h1>
          <p className="text-sm text-[#64748B] mt-1">
            Đăng nhập để tiếp tục sử dụng dịch vụ
          </p>
        </div>

        {error && (
          <div className="mb-4 p-3.5 rounded-xl bg-red-50 border border-red-200 text-red-700 text-sm font-medium">
            {error}
          </div>
        )}
        {notice && (
          <div className="mb-4 p-3.5 rounded-xl bg-[#EAF2FF] border border-[#D8E3F3] text-[#123A73] text-sm font-medium">
            {notice}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {mode === 'login' && (
            <>
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#64748B] mb-1.5">
                  Username hoặc Email
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-[#64748B] absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    value={identifier}
                    onChange={(e) => setIdentifier(e.target.value)}
                    placeholder="Nhập username hoặc email"
                    className="w-full pl-10 pr-4 py-3 rounded-xl border border-[#D8E3F3] bg-[#F5F8FF]/60 text-[#10213A] text-sm focus:outline-none focus:border-[#2563EB] focus:bg-white transition"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#64748B] mb-1.5">
                  Mật khẩu
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-[#64748B] absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Nhập mật khẩu website"
                    className="w-full pl-10 pr-11 py-3 rounded-xl border border-[#D8E3F3] bg-[#F5F8FF]/60 text-[#10213A] text-sm focus:outline-none focus:border-[#2563EB] focus:bg-white transition"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3.5 top-1/2 -translate-y-1/2 text-[#64748B] hover:text-[#10213A]"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between text-xs pt-1">
                <label className="flex items-center gap-2 text-[#64748B] cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="rounded border-[#D8E3F3] text-[#2563EB] focus:ring-[#2563EB]"
                  />
                  Ghi nhớ đăng nhập
                </label>
                <button
                  type="button"
                  onClick={() => { setMode('forgot'); setError(null); }}
                  className="font-semibold text-[#2563EB] hover:underline"
                >
                  Quên mật khẩu?
                </button>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3.5 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] active:bg-[#123A73] text-white font-bold text-sm shadow-md transition disabled:opacity-60"
              >
                {loading ? 'Đang xử lý...' : 'Đăng nhập'}
              </button>
            </>
          )}

          {mode === 'register' && (
            <>
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#64748B] mb-1.5">
                  Username
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-[#64748B] absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="Ví dụ: godly_dev"
                    className="w-full pl-10 pr-4 py-3 rounded-xl border border-[#D8E3F3] bg-[#F5F8FF]/60 text-sm focus:outline-none focus:border-[#2563EB] focus:bg-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#64748B] mb-1.5">
                  Email
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-[#64748B] absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@example.com"
                    className="w-full pl-10 pr-4 py-3 rounded-xl border border-[#D8E3F3] bg-[#F5F8FF]/60 text-sm focus:outline-none focus:border-[#2563EB] focus:bg-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#64748B] mb-1.5">
                  Mật khẩu (tối thiểu 8 ký tự, chữ & số)
                </label>
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Nhập mật khẩu"
                  className="w-full px-4 py-3 rounded-xl border border-[#D8E3F3] bg-[#F5F8FF]/60 text-sm focus:outline-none focus:border-[#2563EB] focus:bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#64748B] mb-1.5">
                  Xác nhận mật khẩu
                </label>
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Nhập lại mật khẩu"
                  className="w-full px-4 py-3 rounded-xl border border-[#D8E3F3] bg-[#F5F8FF]/60 text-sm focus:outline-none focus:border-[#2563EB] focus:bg-white"
                />
              </div>

              <label className="flex items-start gap-2.5 text-xs text-[#64748B] cursor-pointer pt-1">
                <input
                  type="checkbox"
                  required
                  checked={termsAccepted}
                  onChange={(e) => setTermsAccepted(e.target.checked)}
                  className="mt-0.5 rounded border-[#D8E3F3] text-[#2563EB]"
                />
                <span>Tôi đồng ý với điều khoản sử dụng và chính sách bảo mật của Godly APK Builder.</span>
              </label>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3.5 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white font-bold text-sm shadow-md transition disabled:opacity-60"
              >
                {loading ? 'Đang tạo tài khoản...' : 'Đăng ký'}
              </button>
            </>
          )}

          {mode === 'forgot' && (
            <>
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#64748B] mb-1.5">
                  Email khôi phục mật khẩu
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Nhập địa chỉ email đã đăng ký"
                  className="w-full px-4 py-3 rounded-xl border border-[#D8E3F3] bg-[#F5F8FF]/60 text-sm focus:outline-none focus:border-[#2563EB] focus:bg-white"
                />
              </div>
              <button
                type="submit"
                disabled={loading}
                className="w-full py-3.5 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white font-bold text-sm shadow-md transition disabled:opacity-60"
              >
                {loading ? 'Đang gửi SMTP...' : 'Gửi email đặt lại mật khẩu'}
              </button>
            </>
          )}
        </form>

        {/* Divider "hoặc" */}
        <div className="relative my-6 flex items-center justify-center">
          <div className="border-t border-[#D8E3F3] w-full" />
          <span className="bg-white px-3 text-xs text-[#64748B] font-medium">hoặc</span>
          <div className="border-t border-[#D8E3F3] w-full" />
        </div>

        {/* GitHub Token Management Info Button (Not OAuth) */}
        <button
          type="button"
          onClick={() => setShowPatGuide(!showPatGuide)}
          className="w-full py-3 px-4 rounded-xl border border-[#D8E3F3] bg-[#EAF2FF]/60 hover:bg-[#EAF2FF] text-[#123A73] font-semibold text-xs flex items-center justify-center gap-2 transition"
        >
          <Github className="w-4 h-4 text-[#2563EB]" />
          <span>Quản lý GitHub Personal Access Token (Sau đăng nhập)</span>
        </button>

        {showPatGuide && (
          <div className="mt-3 p-3.5 rounded-xl bg-[#F5F8FF] border border-[#D8E3F3] text-xs text-[#64748B] space-y-1.5">
            <div className="font-semibold text-[#10213A] flex items-center gap-1.5">
              <KeyRound className="w-3.5 h-3.5 text-[#2563EB]" />
              Cơ chế bảo mật GitHub PAT riêng biệt
            </div>
            <p>
              • Website không dùng GitHub OAuth và không dùng GitHub Token làm mật khẩu đăng nhập.
            </p>
            <p>
              • Sau khi đăng nhập tài khoản website, bạn kết nối GitHub PAT riêng (mã hóa chuẩn AES-256-GCM) để biên dịch APK qua GitHub Actions của chính bạn.
            </p>
          </div>
        )}

        <div className="mt-6 text-center text-sm text-[#64748B]">
          {mode === 'login' ? (
            <>
              Chưa có tài khoản?{' '}
              <button
                type="button"
                onClick={() => { setMode('register'); setError(null); }}
                className="font-bold text-[#2563EB] hover:underline"
              >
                Đăng ký ngay
              </button>
            </>
          ) : (
            <>
              Đã có tài khoản?{' '}
              <button
                type="button"
                onClick={() => { setMode('login'); setError(null); }}
                className="font-bold text-[#2563EB] hover:underline"
              >
                Đăng nhập
              </button>
            </>
          )}
        </div>
      </div>

      {/* Footer */}
      <footer className="mt-7 text-xs font-semibold tracking-widest uppercase text-[#64748B]">
        Build · Create · Share
      </footer>
    </div>
  );
};
