import React, { useState, useEffect, useRef } from 'react';
import {
  FileArchive, UploadCloud, Trash2, RefreshCw, Play, XCircle,
  CheckCircle2, AlertTriangle, Download, Github, LogOut, History, Loader2, ShieldAlert
} from 'lucide-react';
import { apiRequest, getApiBase } from '../services/api';
import { BuildState, GitHubConnectionInfo, QuotaInfo, UserInfo } from '../types';
import { GitHubPatModal } from './GitHubPatModal';

interface Props {
  user: UserInfo;
  github: GitHubConnectionInfo;
  quota: QuotaInfo;
  initialBuild: BuildState | null;
  onRefreshProfile: () => Promise<void>;
  onLogout: () => Promise<void>;
}

export const MainBuildScreen: React.FC<Props> = ({
  user,
  github,
  quota,
  initialBuild,
  onRefreshProfile,
  onLogout
}) => {
  const [buildState, setBuildState] = useState<BuildState | null>(initialBuild);
  const [uploading, setUploading] = useState(false);
  const [submittingBuild, setSubmittingBuild] = useState(false);
  const [uiError, setUiError] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [showGitHubModal, setShowGitHubModal] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [historyList, setHistoryList] = useState<BuildState[]>([]);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    setBuildState(initialBuild);
  }, [initialBuild]);

  // Poll / Sync active build status across tabs & page refresh
  useEffect(() => {
    if (!buildState) return;
    if (['SUCCESS', 'FAILED', 'CANCELLED'].includes(buildState.status)) return;

    const timer = setInterval(async () => {
      try {
        const latest = await apiRequest<BuildState>(`/api/build/${buildState.build_id}/status`);
        setBuildState(latest);
      } catch {
        // Ignore transient network errors during poll
      }
    }, 2500);

    return () => clearInterval(timer);
  }, [buildState?.build_id, buildState?.status]);

  const isBuildRunning = Boolean(
    buildState && !['SUCCESS', 'FAILED', 'CANCELLED'].includes(buildState.status)
  );

  const formatBytes = (bytes?: number | null) => {
    if (!bytes || bytes <= 0) return '0 MB';
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  const formatDuration = (sec?: number) => {
    const s = Math.max(0, sec || 0);
    const m = Math.floor(s / 60);
    const rem = s % 60;
    return `${m}p ${rem < 10 ? '0' : ''}${rem}s`;
  };

  const handleFileUpload = async (file: File) => {
    if (isBuildRunning) {
      setUiError('Không thể thay đổi file ZIP khi đang có tiến trình build đang chạy.');
      return;
    }
    if (!file.name.toLowerCase().endsWith('.zip')) {
      setUiError('Vui lòng chọn file định dạng .zip hợp lệ.');
      return;
    }
    if (file.size > 25 * 1024 * 1024) {
      setUiError('Dung lượng file ZIP vượt quá giới hạn mặc định 25 MB.');
      return;
    }

    setUiError(null);
    setUploading(true);
    try {
      const formData = new FormData();
      formData.append('file', file);
      await apiRequest('/api/upload/zip', {
        method: 'POST',
        body: formData
      });
      await onRefreshProfile();
    } catch (err: any) {
      setUiError(err.message || 'Lỗi tải lên file ZIP.');
    } finally {
      setUploading(false);
    }
  };

  const handleRemoveZip = async () => {
    if (isBuildRunning) return;
    setUiError(null);
    try {
      await apiRequest('/api/upload/pending', { method: 'DELETE' });
      await onRefreshProfile();
    } catch (err: any) {
      setUiError(err.message);
    }
  };

  const handleStartBuild = async () => {
    if (isBuildRunning || submittingBuild || !quota.pending_zip_name) return;
    if (github.status !== 'CONNECTED') {
      setShowGitHubModal(true);
      return;
    }
    setUiError(null);
    setSubmittingBuild(true);
    try {
      const started = await apiRequest<BuildState>('/api/build/start', {
        method: 'POST',
        body: JSON.stringify({
          repo_full_name: github.selected_repo_full_name || undefined,
          java_version: '17'
        })
      });
      setBuildState(started);
    } catch (err: any) {
      setUiError(err.message || 'Không thể bắt đầu tiến trình build.');
    } finally {
      setSubmittingBuild(false);
    }
  };

  const handleCancelBuild = async () => {
    if (!buildState) return;
    try {
      const cancelled = await apiRequest<BuildState>(`/api/build/${buildState.build_id}/cancel`, {
        method: 'POST'
      });
      setBuildState(cancelled);
    } catch (err: any) {
      setUiError(err.message);
    }
  };

  const handleRetryBuild = async () => {
    if (!buildState || isBuildRunning) return;
    setUiError(null);
    setSubmittingBuild(true);
    try {
      const retried = await apiRequest<BuildState>(`/api/build/${buildState.build_id}/retry`, {
        method: 'POST'
      });
      setBuildState(retried);
    } catch (err: any) {
      setUiError(err.message);
    } finally {
      setSubmittingBuild(false);
    }
  };

  const handleDownloadApk = () => {
    if (!buildState || buildState.status !== 'SUCCESS' || !buildState.artifact_available) return;
    window.location.href = `${getApiBase()}/api/apk/${buildState.build_id}/download`;
  };

  const loadHistory = async () => {
    try {
      const res = await apiRequest<{ builds: BuildState[] }>('/api/history');
      setHistoryList(res.builds || []);
      setShowHistory(!showHistory);
    } catch (err: any) {
      setUiError(err.message);
    }
  };

  const radius = 32;
  const circumference = 2 * Math.PI * radius;
  const progressValue = buildState ? Math.min(100, Math.max(0, buildState.progress_percent)) : 0;
  const strokeDashoffset = circumference - (progressValue / 100) * circumference;

  return (
    <div className="min-h-screen bg-[#F5F8FF] text-[#10213A] pb-14">
      {/* 1. HEADER */}
      <header className="sticky top-0 z-30 bg-[#FFFFFF]/95 backdrop-blur-md border-b border-[#D8E3F3]">
        <div className="max-w-2xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#2563EB] to-[#123A73] flex items-center justify-center text-white shadow-sm">
              <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                <path d="M17.523 15.3414c-.5511 0-.9993-.4486-.9993-.9997s.4482-.9993.9993-.9993c.5511 0 .9993.4482.9993.9993.0001.5511-.4482.9997-.9993.9997m-11.046 0c-.5511 0-.9993-.4486-.9993-.9997s.4482-.9993.9993-.9993c.5511 0 .9993.4482.9993.9993 0 .5511-.4482.9997-.9993.9997m11.4045-6.02l1.9973-3.4592a.416.416 0 00-.1521-.5676.416.416 0 00-.5676.1521l-2.0223 3.503C15.5902 8.2439 13.8533 7.8508 12 7.8508s-3.5902.3931-5.1367 1.0989L4.841 5.4467a.4161.4161 0 00-.5677-.1521.4157.4157 0 00-.1521.5676l1.9973 3.4592C2.6889 11.1867.3432 14.6589 0 18.761h24c-.3435-4.1021-2.6892-7.5743-6.1185-9.4396" />
              </svg>
            </div>
            <span className="font-extrabold text-base sm:text-lg tracking-tight text-[#10213A]">
              Godly APK Builder
            </span>
          </div>

          <div className="flex items-center gap-2">
            {/* GitHub Status Button */}
            <button
              type="button"
              onClick={() => setShowGitHubModal(true)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold border flex items-center gap-1.5 transition ${
                github.status === 'CONNECTED'
                  ? 'bg-[#EAF2FF] border-[#D8E3F3] text-[#123A73]'
                  : 'bg-amber-50 border-amber-200 text-amber-800'
              }`}
            >
              <span
                className={`w-2 h-2 rounded-full ${
                  github.status === 'CONNECTED' ? 'bg-emerald-500' : 'bg-amber-500'
                }`}
              />
              <Github className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">
                {github.status === 'CONNECTED' ? `@${github.github_username}` : 'Kết nối GitHub'}
              </span>
            </button>

            {/* Build History Toggle */}
            <button
              type="button"
              onClick={loadHistory}
              title="Lịch sử Build"
              className="p-2 rounded-xl border border-[#D8E3F3] bg-white hover:bg-[#EAF2FF] text-[#123A73]"
            >
              <History className="w-4 h-4" />
            </button>

            {/* User Badge & Logout */}
            <div className="flex items-center gap-1.5 pl-1">
              <div className="w-8 h-8 rounded-full bg-[#EAF2FF] border border-[#D8E3F3] flex items-center justify-center text-xs font-bold text-[#2563EB]">
                {user.username.slice(0, 2).toUpperCase()}
              </div>
              <button
                type="button"
                onClick={onLogout}
                title="Đăng xuất"
                className="p-2 rounded-xl border border-[#D8E3F3] bg-white hover:bg-red-50 text-[#64748B] hover:text-red-600 transition"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-xl mx-auto px-4 pt-6 space-y-5">
        {uiError && (
          <div className="p-4 rounded-2xl bg-red-50 border border-red-200 text-red-700 text-sm font-medium flex items-start gap-2.5">
            <AlertTriangle className="w-5 h-5 shrink-0 mt-0.5" />
            <span>{uiError}</span>
          </div>
        )}

        {/* 2. ZIP UPLOAD CARD */}
        <section className="bg-[#FFFFFF] border border-[#D8E3F3] rounded-3xl p-6 shadow-[0_10px_30px_rgba(18,58,115,0.06)]">
          <div className="flex items-center justify-between mb-4">
            <span className="text-xs font-bold uppercase tracking-wider text-[#64748B]">
              Dự án Android nguồn (ZIP 1)
            </span>
            <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-[#EAF2FF] text-[#2563EB]">
              Quota: {quota.remaining_uploads}/{quota.max_uploads} lượt còn lại
            </span>
          </div>

          <input
            ref={fileInputRef}
            type="file"
            accept=".zip,application/zip"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) handleFileUpload(f);
              e.target.value = '';
            }}
          />

          {!quota.pending_zip_name ? (
            <div
              onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
              onDragLeave={() => setIsDragging(false)}
              onDrop={(e) => {
                e.preventDefault();
                setIsDragging(false);
                const f = e.dataTransfer.files?.[0];
                if (f) handleFileUpload(f);
              }}
              className={`border-2 border-dashed rounded-2xl p-8 text-center transition ${
                isDragging ? 'border-[#2563EB] bg-[#EAF2FF]/70' : 'border-[#D8E3F3] bg-[#F5F8FF]/70'
              }`}
            >
              <div className="w-14 h-14 mx-auto rounded-2xl bg-[#EAF2FF] text-[#2563EB] flex items-center justify-center mb-3">
                <FileArchive className="w-7 h-7" />
              </div>
              <h2 className="text-base font-bold text-[#10213A]">Chọn file ZIP của bạn</h2>
              <p className="text-xs text-[#64748B] mt-1">
                File ZIP chứa dự án Android · Tối đa 25 MB
              </p>
              <button
                type="button"
                disabled={uploading || isBuildRunning}
                onClick={() => fileInputRef.current?.click()}
                className="mt-4 px-5 py-2.5 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white text-xs font-bold shadow-sm transition disabled:opacity-50 inline-flex items-center gap-2"
              >
                <UploadCloud className="w-4 h-4" />
                {uploading ? 'Đang kiểm tra & tải lên...' : 'Chọn file'}
              </button>
            </div>
          ) : (
            <div className="p-4 rounded-2xl bg-[#EAF2FF]/60 border border-[#D8E3F3] space-y-3">
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-12 h-12 rounded-2xl bg-[#2563EB] text-white flex items-center justify-center shrink-0">
                    <FileArchive className="w-6 h-6" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm font-bold text-[#10213A] truncate">
                      {quota.pending_zip_name}
                    </p>
                    <p className="text-xs text-[#64748B]">
                      {formatBytes(quota.pending_zip_size)} · Xuất APK: <strong className="text-[#123A73]">{quota.pending_apk_name}</strong>
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 pt-1">
                <button
                  type="button"
                  disabled={isBuildRunning || uploading}
                  onClick={() => fileInputRef.current?.click()}
                  className="flex-1 py-2 px-3 rounded-xl border border-[#D8E3F3] bg-white hover:bg-[#F5F8FF] text-xs font-semibold text-[#123A73] flex items-center justify-center gap-1.5 disabled:opacity-50"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  Chọn ZIP khác
                </button>
                <button
                  type="button"
                  disabled={isBuildRunning || uploading}
                  onClick={handleRemoveZip}
                  className="py-2 px-3 rounded-xl border border-red-200 bg-red-50 hover:bg-red-100 text-xs font-semibold text-red-600 flex items-center justify-center gap-1.5 disabled:opacity-50"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  Xóa ZIP
                </button>
              </div>
            </div>
          )}
        </section>

        {/* 3. NÚT TẠO APK */}
        <button
          type="button"
          disabled={!quota.pending_zip_name || isBuildRunning || submittingBuild}
          onClick={handleStartBuild}
          className="w-full py-4 rounded-2xl bg-gradient-to-r from-[#2563EB] to-[#1D4ED8] hover:from-[#1D4ED8] hover:to-[#123A73] text-white font-extrabold text-base tracking-wide shadow-[0_10px_25px_rgba(37,99,235,0.28)] transition flex items-center justify-center gap-2.5 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {submittingBuild || isBuildRunning ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              <span>ĐANG XỬ LÝ BUILD APK...</span>
            </>
          ) : (
            <>
              <Play className="w-5 h-5 fill-current" />
              <span>TẠO APK</span>
            </>
          )}
        </button>

        {/* 4. BUILD PROGRESS CARD (Deep Navy #0B1F44 -> #123A73) */}
        {buildState && (
          <section className="rounded-3xl bg-gradient-to-br from-[#0B1F44] to-[#123A73] text-white p-6 shadow-[0_16px_40px_rgba(11,31,68,0.28)] border border-[#1E3A8A]/40">
            <div className="flex items-center justify-between gap-4 mb-5">
              <div className="flex items-center gap-4">
                {/* Progress Ring */}
                <div className="relative w-20 h-20 flex items-center justify-center shrink-0">
                  <svg className="w-20 h-20 -rotate-90" viewBox="0 0 80 80">
                    <circle
                      cx="40"
                      cy="40"
                      r={radius}
                      stroke="rgba(255,255,255,0.15)"
                      strokeWidth="7"
                      fill="transparent"
                    />
                    <circle
                      cx="40"
                      cy="40"
                      r={radius}
                      stroke="#3B82F6"
                      strokeWidth="7"
                      strokeDasharray={circumference}
                      strokeDashoffset={strokeDashoffset}
                      strokeLinecap="round"
                      fill="transparent"
                    />
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <span className="text-base font-extrabold">{progressValue}%</span>
                    {buildState.is_estimated_progress && (
                      <span className="text-[9px] uppercase tracking-wider text-blue-200">Est.</span>
                    )}
                  </div>
                </div>

                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold uppercase tracking-wider bg-white/10 text-blue-200">
                      {buildState.status}
                    </span>
                    <span className="text-xs text-blue-200 font-mono">
                      {formatDuration(buildState.duration_seconds)}
                    </span>
                  </div>
                  <h3 className="text-sm sm:text-base font-bold mt-1.5 leading-snug">
                    {buildState.status_text}
                  </h3>
                  <p className="text-[11px] text-blue-200/80 font-mono mt-0.5">
                    Build ID: {buildState.build_id.slice(0, 12)} · {buildState.zip_name} → {buildState.apk_name}
                  </p>
                </div>
              </div>
            </div>

            {/* Linear Progress Bar */}
            <div className="w-full h-2.5 bg-white/10 rounded-full overflow-hidden mb-5">
              <div
                className={`h-full transition-all duration-500 rounded-full ${
                  buildState.status === 'FAILED'
                    ? 'bg-red-400'
                    : buildState.status === 'CANCELLED'
                    ? 'bg-amber-400'
                    : 'bg-[#2563EB]'
                }`}
                style={{ width: `${progressValue}%` }}
              />
            </div>

            {/* 6 Build Steps */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 mb-5">
              {buildState.steps.map((step) => (
                <div
                  key={step.step_number}
                  className={`px-3.5 py-2.5 rounded-xl border text-xs flex items-center justify-between ${
                    step.status === 'completed'
                      ? 'bg-white/10 border-emerald-400/30 text-white'
                      : step.status === 'running'
                      ? 'bg-[#2563EB]/30 border-blue-400 text-white font-bold'
                      : step.status === 'failed'
                      ? 'bg-red-500/20 border-red-400/50 text-red-100'
                      : 'bg-white/5 border-white/10 text-blue-200/60'
                  }`}
                >
                  <span>
                    {step.step_number}. {step.title}
                  </span>
                  {step.status === 'completed' && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
                  {step.status === 'running' && <Loader2 className="w-4 h-4 text-blue-300 animate-spin" />}
                  {step.status === 'failed' && <XCircle className="w-4 h-4 text-red-400" />}
                </div>
              ))}
            </div>

            {/* Error Analyzer Box on Failure */}
            {buildState.status === 'FAILED' && (
              <div className="p-4 rounded-2xl bg-red-950/60 border border-red-400/40 text-xs space-y-2 mb-4">
                <div className="font-bold text-red-200 flex items-center gap-1.5">
                  <ShieldAlert className="w-4 h-4 text-red-300" />
                  <span>Phân tích lỗi ({buildState.error_code}):</span>
                </div>
                <p className="text-white/90">{buildState.error_summary_vi}</p>
                {buildState.error_suggestion_vi && (
                  <p className="text-blue-200">
                    <strong>Đề xuất sửa:</strong> {buildState.error_suggestion_vi}
                  </p>
                )}
              </div>
            )}

            {/* Cancel or Retry Controls */}
            <div className="flex items-center justify-end gap-2.5">
              {isBuildRunning && (
                <button
                  type="button"
                  onClick={handleCancelBuild}
                  className="px-4 py-2 rounded-xl bg-white/10 hover:bg-red-500/30 border border-white/20 text-xs font-bold text-white transition"
                >
                  Hủy Build (Cancel)
                </button>
              )}
              {(buildState.status === 'FAILED' || buildState.status === 'CANCELLED') && (
                <button
                  type="button"
                  onClick={handleRetryBuild}
                  className="px-4 py-2 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-xs font-bold text-white flex items-center gap-1.5 transition"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  Retry Build
                </button>
              )}
            </div>
          </section>
        )}

        {/* 5. APK DOWNLOAD CARD (Appears automatically right below Progress Card when SUCCESS) */}
        {buildState && buildState.status === 'SUCCESS' && buildState.artifact_available && (
          <section className="bg-[#FFFFFF] border-2 border-[#2563EB]/30 rounded-3xl p-6 shadow-[0_14px_35px_rgba(37,99,235,0.12)] flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#2563EB] to-[#123A73] text-white flex items-center justify-center shrink-0 shadow-md">
                <Download className="w-7 h-7" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-lg font-extrabold text-[#10213A]">
                    {buildState.apk_name}
                  </h3>
                  <span className="px-2 py-0.5 rounded-md bg-[#EAF2FF] text-[#2563EB] text-[11px] font-bold">
                    {buildState.apk_version || 'v1.0-debug'}
                  </span>
                </div>
                <p className="text-xs font-semibold text-[#64748B] mt-0.5">
                  {formatBytes(buildState.apk_size)} · APK
                </p>
                <p className="text-xs font-bold text-emerald-600 mt-1 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  Build thành công!
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={handleDownloadApk}
              className="w-full sm:w-auto px-6 py-3.5 rounded-2xl bg-[#0B1F44] hover:bg-[#123A73] text-white font-extrabold text-sm tracking-wide shadow-md flex items-center justify-center gap-2 transition"
            >
              <Download className="w-4 h-4" />
              <span>TẢI APK</span>
            </button>
          </section>
        )}

        {/* Build History Section (when toggled) */}
        {showHistory && (
          <section className="bg-white border border-[#D8E3F3] rounded-3xl p-5 space-y-3 shadow-sm">
            <h3 className="text-sm font-bold text-[#10213A]">Lịch sử Build của bạn</h3>
            {historyList.length === 0 ? (
              <p className="text-xs text-[#64748B]">Chưa có bản build nào.</p>
            ) : (
              <div className="space-y-2">
                {historyList.map((item) => (
                  <div
                    key={item.build_id}
                    onClick={() => setBuildState(item)}
                    className="p-3 rounded-xl border border-[#D8E3F3] hover:bg-[#F5F8FF] cursor-pointer flex items-center justify-between text-xs"
                  >
                    <div>
                      <p className="font-bold text-[#10213A]">{item.zip_name} → {item.apk_name}</p>
                      <p className="text-[#64748B] font-mono">
                        ID: {item.build_id.slice(0, 8)} · {formatDuration(item.duration_seconds)}
                      </p>
                    </div>
                    <span className="font-bold text-[#2563EB]">{item.status}</span>
                  </div>
                ))}
              </div>
            )}
          </section>
        )}
      </main>

      <GitHubPatModal
        isOpen={showGitHubModal}
        onClose={() => setShowGitHubModal(false)}
        githubInfo={github}
        onUpdated={onRefreshProfile}
      />
    </div>
  );
};
