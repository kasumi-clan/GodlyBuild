export type BuildStatusType =
  | 'QUEUED'
  | 'UPLOADING'
  | 'EXTRACTING'
  | 'CONFIGURING'
  | 'BUILDING'
  | 'PACKAGING'
  | 'SUCCESS'
  | 'FAILED'
  | 'CANCELLED';

export interface BuildStepItem {
  step_number: number;
  title: string;
  status: 'pending' | 'running' | 'completed' | 'failed' | 'cancelled';
}

export interface BuildState {
  build_id: string;
  user_id: string;
  repo_full_name: string;
  zip_name: string;
  zip_size: number;
  apk_name: string;
  status: BuildStatusType;
  progress_percent: number;
  is_estimated_progress: boolean;
  current_step: number;
  status_text: string;
  is_locked: boolean;
  started_at: string;
  finished_at?: string | null;
  duration_seconds: number;
  steps: BuildStepItem[];
  error_code?: string | null;
  error_summary_vi?: string | null;
  error_suggestion_vi?: string | null;
  artifact_available: boolean;
  apk_size?: number | null;
  apk_version?: string | null;
}

export interface GitHubConnectionInfo {
  status: 'CONNECTED' | 'DISCONNECTED';
  github_username?: string;
  avatar_url?: string;
  masked_pat?: string;
  scopes?: string;
  selected_repo_full_name?: string;
}

export interface QuotaInfo {
  max_uploads: number;
  used_uploads: number;
  remaining_uploads: number;
  reset_policy: string;
  pending_zip_id?: string | null;
  pending_zip_name?: string | null;
  pending_zip_size?: number | null;
  pending_apk_name?: string | null;
}

export interface UserInfo {
  id: string;
  username: string;
  email: string;
  is_admin?: boolean;
}
