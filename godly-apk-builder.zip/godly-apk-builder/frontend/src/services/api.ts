const API_BASE = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000';

let csrfTokenMemory = '';

export function setCsrfToken(token: string) {
  csrfTokenMemory = token;
}

export function getApiBase(): string {
  return API_BASE;
}

export async function apiRequest<T = any>(
  path: string,
  options: RequestInit = {}
): Promise<T> {
  const headers = new Headers(options.headers || {});
  if (!(options.body instanceof FormData) && !headers.has('Content-Type')) {
    headers.set('Content-Type', 'application/json');
  }
  if (csrfTokenMemory) {
    headers.set('X-CSRF-Token', csrfTokenMemory);
  }
  const res = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers,
    credentials: 'include'
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.detail || data.message || `Lỗi HTTP ${res.status}`);
  }
  return data as T;
}
