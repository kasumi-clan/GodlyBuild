import React, { useEffect, useState } from 'react';
import { AuthScreen } from './components/AuthScreen';
import { MainBuildScreen } from './components/MainBuildScreen';
import { apiRequest, setCsrfToken } from './services/api';
import { BuildState, GitHubConnectionInfo, QuotaInfo, UserInfo } from './types';

export function App() {
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState<UserInfo | null>(null);
  const [github, setGithub] = useState<GitHubConnectionInfo>({ status: 'DISCONNECTED' });
  const [quota, setQuota] = useState<QuotaInfo>({
    max_uploads: 10,
    used_uploads: 0,
    remaining_uploads: 10,
    reset_policy: 'manual'
  });
  const [latestBuild, setLatestBuild] = useState<BuildState | null>(null);

  const loadSession = async () => {
    try {
      const data = await apiRequest('/api/auth/me');
      if (data.csrf_token) {
        setCsrfToken(data.csrf_token);
      }
      setUser(data.user);
      setGithub(data.github || { status: 'DISCONNECTED' });
      setQuota(data.quota);
      setLatestBuild(data.active_or_latest_build || null);
    } catch {
      setUser(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadSession();
  }, []);

  const handleLogout = async () => {
    await apiRequest('/api/auth/logout', { method: 'POST' }).catch(() => {});
    setUser(null);
    setLatestBuild(null);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#F5F8FF] flex items-center justify-center text-sm font-semibold text-[#123A73]">
        Đang tải Godly APK Builder...
      </div>
    );
  }

  if (!user) {
    return <AuthScreen onLoginSuccess={loadSession} />;
  }

  return (
    <MainBuildScreen
      user={user}
      github={github}
      quota={quota}
      initialBuild={latestBuild}
      onRefreshProfile={loadSession}
      onLogout={handleLogout}
    />
  );
}

export default App;
