/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        godlyBg: '#F5F8FF',
        godlyWhite: '#FFFFFF',
        godlyPrimary: '#2563EB',
        godlyNavy: '#0B1F44',
        godlyDarkBlue: '#123A73',
        godlyLightBlue: '#EAF2FF',
        godlyBorder: '#D8E3F3',
        godlyText: '#10213A',
        godlySecondary: '#64748B'
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', '-apple-system', 'sans-serif']
      }
    }
  },
  plugins: []
};
