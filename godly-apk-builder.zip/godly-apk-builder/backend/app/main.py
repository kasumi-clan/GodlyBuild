from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.config import settings
from app.routers import auth, github, upload, build

app = FastAPI(
    title=settings.APP_NAME,
    version="1.0.0",
    description="Godly APK Builder — Production Android APK Cloud Compiler via GitHub Actions",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["Content-Type", "X-CSRF-Token", "Authorization"],
)

app.include_router(auth.router)
app.include_router(github.router)
app.include_router(upload.router)
app.include_router(build.router)

@app.get("/api/health")
def health_check():
    return {"status": "ok", "service": settings.APP_NAME}
