import os
import re
import zipfile
from dataclasses import dataclass
from typing import List, Optional
from pathlib import Path

class AndroidProjectError(Exception):
    def __init__(self, code: str, message_vi: str):
        super().__init__(message_vi)
        self.code = code
        self.message_vi = message_vi

@dataclass
class DetectedAndroidProject:
    android_root: str
    settings_file: str
    app_module: str
    all_app_modules: List[str]
    java_version: str
    has_gradlew: bool

@dataclass
class VerifiedApkArtifact:
    apk_path: str
    apk_name: str
    apk_size: int
    version_name: Optional[str]

def detect_android_project(extracted_dir: str, preferred_java: str = "17") -> DetectedAndroidProject:
    settings_candidates = []
    any_gradle = False
    for root, dirs, files in os.walk(extracted_dir):
        dirs[:] = [d for d in dirs if d not in (".git", ".gradle", "build", "__MACOSX")]
        if any(f in files for f in ("build.gradle", "build.gradle.kts")):
            any_gradle = True
        if "settings.gradle.kts" in files:
            settings_candidates.append((root[len(extracted_dir):].count(os.sep), root, "settings.gradle.kts"))
        elif "settings.gradle" in files:
            settings_candidates.append((root[len(extracted_dir):].count(os.sep), root, "settings.gradle"))
    if not settings_candidates:
        if any_gradle:
            raise AndroidProjectError("MISSING_SETTINGS_GRADLE", "Thiếu tệp settings.gradle hoặc settings.gradle.kts.")
        raise AndroidProjectError("NOT_ANDROID_PROJECT", "Không tìm thấy dự án Android hợp lệ trong ZIP.")
    settings_candidates.sort(key=lambda x: x[0])
    _, android_root, settings_file = settings_candidates[0]

    app_modules = []
    detected_java = preferred_java or "17"
    for root, dirs, files in os.walk(android_root):
        for bf in ("build.gradle.kts", "build.gradle"):
            if bf in files:
                txt = Path(os.path.join(root, bf)).read_text(encoding="utf-8", errors="ignore")
                if "com.android.application" in txt:
                    rel = os.path.relpath(root, android_root)
                    app_modules.append("app" if rel == "." else rel.replace(os.sep, ":"))
                if "VERSION_21" in txt:
                    detected_java = "21"
    if not app_modules:
        raise AndroidProjectError("MISSING_APP_MODULE", "Không tìm thấy module ứng dụng Android (:app).")
    selected = "app" if "app" in app_modules else app_modules[0]
    return DetectedAndroidProject(
        android_root=android_root,
        settings_file=settings_file,
        app_module=selected,
        all_app_modules=app_modules,
        java_version=detected_java,
        has_gradlew=os.path.isfile(os.path.join(android_root, "gradlew")),
    )

def find_and_verify_built_apk(android_root: str, target_module: str, desired_apk_name: str) -> VerifiedApkArtifact:
    candidates = []
    for root, dirs, files in os.walk(android_root):
        for fname in files:
            if fname.lower().endswith(".apk") and "unaligned" not in fname.lower():
                full_p = os.path.join(root, fname)
                size = os.path.getsize(full_p)
                if size > 64 and zipfile.is_zipfile(full_p):
                    with zipfile.ZipFile(full_p, "r") as zf:
                        if "AndroidManifest.xml" in zf.namelist():
                            candidates.append((size, full_p))
    if not candidates:
        raise AndroidProjectError("ARTIFACT_MISSING", "Không tìm thấy file APK thực tế sau khi build.")
    candidates.sort(key=lambda x: x[0], reverse=True)
    best_size, best_path = candidates[0]
    version_name = "1.0-debug"
    mod_dir = os.path.join(android_root, target_module.replace(":", os.sep))
    for bf in ("build.gradle.kts", "build.gradle"):
        bp = Path(mod_dir) / bf
        if bp.is_file():
            txt = bp.read_text(encoding="utf-8", errors="ignore")
            m = re.search(r"versionName\s*[=:\s]+[\"\']([^\"\']+)[\"\']", txt)
            if m:
                version_name = m.group(1)
                break
    return VerifiedApkArtifact(apk_path=best_path, apk_name=desired_apk_name, apk_size=best_size, version_name=version_name)
