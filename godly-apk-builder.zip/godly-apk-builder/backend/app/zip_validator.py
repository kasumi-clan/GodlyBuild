import os
import re
import stat
import shutil
import hashlib
import zipfile
from dataclasses import dataclass
from typing import Optional
from app.config import settings

STATIC_ZIP_0_NAMES = {"samplezeroapp.zip", "zip0.zip", "example_static_zip0.zip"}

class ZipValidationError(Exception):
    def __init__(self, code: str, message_vi: str):
        super().__init__(message_vi)
        self.code = code
        self.message_vi = message_vi

@dataclass
class ValidatedZipMetadata:
    zip_filename: str
    apk_filename: str
    file_size: int
    unpacked_size: int
    entry_count: int
    sha256_hex: str
    is_session_zip_1: bool = True

def derive_apk_name_from_zip(zip_filename: str) -> str:
    if not zip_filename or not zip_filename.strip():
        raise ZipValidationError("INVALID_ZIP", "Tên file ZIP không hợp lệ.")
    base = os.path.basename(zip_filename.strip().replace("\\", "/"))
    stem = base[:-4] if base.lower().endswith(".zip") else base
    stem = re.sub(r"[<>:/\\|?*\x00-\x1f]", "_", stem).strip(" .")
    if not stem:
        raise ZipValidationError("INVALID_ZIP", "Tên file ZIP không hợp lệ.")
    return f"{stem}.apk"

def validate_zip_file(
    zip_path: str,
    original_filename: str,
    max_upload_bytes: Optional[int] = None,
    max_unpacked_bytes: Optional[int] = None,
    max_entries: int = 10000,
) -> ValidatedZipMetadata:
    limit_upload = max_upload_bytes if max_upload_bytes is not None else settings.max_upload_bytes
    limit_unpacked = max_unpacked_bytes if max_unpacked_bytes is not None else settings.max_unpacked_bytes

    if not original_filename or not original_filename.lower().endswith(".zip"):
        raise ZipValidationError("INVALID_ZIP", "Chỉ chấp nhận định dạng file .zip hợp lệ.")
    clean_name = os.path.basename(original_filename.strip().replace("\\", "/"))
    if clean_name.lower() in STATIC_ZIP_0_NAMES:
        raise ZipValidationError("INVALID_ZIP", "ZIP 0 là file mẫu tĩnh, không được dùng để build.")
    if not os.path.isfile(zip_path):
        raise ZipValidationError("INVALID_ZIP", "Không tìm thấy file ZIP đã tải lên.")
    file_size = os.path.getsize(zip_path)
    if file_size <= 0 or file_size > limit_upload:
        raise ZipValidationError("INVALID_ZIP", "Dung lượng file ZIP không hợp lệ hoặc vượt quá 25 MB.")
    if not zipfile.is_zipfile(zip_path):
        raise ZipValidationError("INVALID_ZIP", "File ZIP bị hỏng hoặc sai định dạng.")

    with open(zip_path, "rb") as _f:
        sha256_hex = hashlib.sha256(_f.read()).hexdigest()
    total_unpacked = 0
    with zipfile.ZipFile(zip_path, "r") as zf:
        if zf.testzip() is not None:
            raise ZipValidationError("INVALID_ZIP", "File ZIP bị lỗi CRC.")
        infos = zf.infolist()
        if not infos or len(infos) > max_entries:
            raise ZipValidationError("INVALID_ZIP", "Số lượng tệp trong ZIP không hợp lệ.")
        for info in infos:
            norm = info.filename.replace("\\", "/")
            if norm.startswith("/") or ".." in norm.split("/") or ":" in norm:
                raise ZipValidationError("INVALID_ZIP", f"Phát hiện Zip Slip / Path Traversal: {info.filename}")
            if stat.S_ISLNK((info.external_attr >> 16) & 0xFFFF):
                raise ZipValidationError("INVALID_ZIP", "Không cho phép chứa symlink trong ZIP.")
            total_unpacked += info.file_size
            if total_unpacked > limit_unpacked:
                raise ZipValidationError("INVALID_ZIP", "Tổng dung lượng giải nén vượt quá 250 MB (Zip Bomb).")

    return ValidatedZipMetadata(
        zip_filename=clean_name,
        apk_filename=derive_apk_name_from_zip(clean_name),
        file_size=file_size,
        unpacked_size=total_unpacked,
        entry_count=len(infos),
        sha256_hex=sha256_hex,
    )

def extract_zip_safely(zip_path: str, extract_dir: str, original_filename: str = "project.zip") -> ValidatedZipMetadata:
    meta = validate_zip_file(zip_path, original_filename)
    if os.path.exists(extract_dir):
        shutil.rmtree(extract_dir)
    os.makedirs(extract_dir, exist_ok=True)
    real_root = os.path.realpath(extract_dir)
    with zipfile.ZipFile(zip_path, "r") as zf:
        for info in zf.infolist():
            norm = info.filename.replace("\\", "/")
            if ".github/workflows" in norm.lower():
                continue
            dest = os.path.realpath(os.path.join(real_root, norm))
            if not (dest == real_root or dest.startswith(real_root + os.sep)):
                raise ZipValidationError("INVALID_ZIP", "Chặn giải nén vượt ngoài thư mục cô lập.")
            if info.is_dir():
                os.makedirs(dest, exist_ok=True)
            else:
                os.makedirs(os.path.dirname(dest), exist_ok=True)
                with zf.open(info, "r") as src, open(dest, "wb") as dst:
                    shutil.copyfileobj(src, dst)
    return meta
