import re
import hmac
import time
import hashlib
import secrets
from typing import Dict, List, Tuple
from app.config import settings

try:
    from argon2 import PasswordHasher
    from argon2.exceptions import VerifyMismatchError, InvalidHashError
    _ARGON2_HASHER = PasswordHasher(time_cost=3, memory_cost=65536, parallelism=4, hash_len=32, salt_len=16)
    HAS_ARGON2_CFFI = True
except ImportError:
    _ARGON2_HASHER = None
    HAS_ARGON2_CFFI = False

def hash_password(password: str) -> str:
    if not password or len(password) < 8:
        raise ValueError("Mật khẩu phải có ít nhất 8 ký tự.")
    if HAS_ARGON2_CFFI and _ARGON2_HASHER is not None:
        return _ARGON2_HASHER.hash(password)
    salt = secrets.token_bytes(16)
    derived = hashlib.scrypt(password.encode("utf-8"), salt=salt, n=16384, r=8, p=1, dklen=32)
    return f"$argon2id-compat$n=16384,r=8,p=1${salt.hex()}${derived.hex()}"

def verify_password(password: str, stored_hash: str) -> bool:
    if not password or not stored_hash:
        return False
    if stored_hash.startswith("$argon2id-compat$"):
        try:
            parts = stored_hash.split("$")
            salt = bytes.fromhex(parts[3])
            expected = bytes.fromhex(parts[4])
            candidate = hashlib.scrypt(password.encode("utf-8"), salt=salt, n=16384, r=8, p=1, dklen=32)
            return hmac.compare_digest(candidate, expected)
        except Exception:
            return False
    if HAS_ARGON2_CFFI and _ARGON2_HASHER is not None:
        try:
            return _ARGON2_HASHER.verify(stored_hash, password)
        except Exception:
            return False
    return False

def validate_password_strength(password: str) -> Tuple[bool, str]:
    if len(password) < 8:
        return False, "Mật khẩu phải có tối thiểu 8 ký tự."
    if len(password) > 128:
        return False, "Mật khẩu không được vượt quá 128 ký tự."
    if not re.search(r"[A-Za-z]", password) or not re.search(r"[0-9]", password):
        return False, "Mật khẩu phải bao gồm cả chữ cái và chữ số."
    return True, "OK"

def generate_session_token() -> Tuple[str, str]:
    raw = secrets.token_urlsafe(48)
    return raw, hashlib.sha256(raw.encode("utf-8")).hexdigest()

def hash_session_token(raw_token: str) -> str:
    return hashlib.sha256(raw_token.encode("utf-8")).hexdigest()

def generate_csrf_token(session_id: str) -> str:
    nonce = secrets.token_hex(16)
    msg = f"{session_id}:{nonce}".encode("utf-8")
    sig = hmac.new(settings.CSRF_SECRET_KEY.encode("utf-8"), msg, hashlib.sha256).hexdigest()
    return f"{nonce}.{sig}"

def verify_csrf_token(session_id: str, csrf_token: str) -> bool:
    if not session_id or not csrf_token or "." not in csrf_token:
        return False
    nonce, provided_sig = csrf_token.split(".", 1)
    msg = f"{session_id}:{nonce}".encode("utf-8")
    expected_sig = hmac.new(settings.CSRF_SECRET_KEY.encode("utf-8"), msg, hashlib.sha256).hexdigest()
    return hmac.compare_digest(provided_sig, expected_sig)

_SECRET_PATTERNS = [
    re.compile(r"gh[pousr]_[A-Za-z0-9_]{20,255}"),
    re.compile(r"github_pat_[A-Za-z0-9_]{20,255}"),
    re.compile(r"(?i)(authorization\s*:\s*(?:bearer|token)\s+)([^\s']+)"),
]

def mask_secrets_in_text(text: str, extra_secrets: List[str] = None) -> str:
    if not text:
        return ""
    cleaned = text
    if extra_secrets:
        for sec in extra_secrets:
            if sec and len(sec) >= 6:
                cleaned = cleaned.replace(sec, "[REDACTED_SECRET]")
    cleaned = _SECRET_PATTERNS[0].sub("[REDACTED_GITHUB_PAT]", cleaned)
    cleaned = _SECRET_PATTERNS[1].sub("[REDACTED_GITHUB_PAT]", cleaned)
    cleaned = _SECRET_PATTERNS[2].sub(r"\1[REDACTED_TOKEN]", cleaned)
    return cleaned

class RateLimiter:
    def __init__(self, max_attempts: int = 5, window_seconds: int = 300):
        self.max_attempts = max_attempts
        self.window_seconds = window_seconds
        self._buckets: Dict[str, List[float]] = {}

    def check_and_record(self, key: str) -> Tuple[bool, int]:
        now = time.time()
        cutoff = now - self.window_seconds
        history = [ts for ts in self._buckets.get(key, []) if ts > cutoff]
        if len(history) >= self.max_attempts:
            retry_after = int(history[0] + self.window_seconds - now) + 1
            self._buckets[key] = history
            return False, max(1, retry_after)
        history.append(now)
        self._buckets[key] = history
        return True, 0

    def reset(self, key: str) -> None:
        self._buckets.pop(key, None)

login_rate_limiter = RateLimiter(max_attempts=5, window_seconds=300)
register_rate_limiter = RateLimiter(max_attempts=3, window_seconds=600)
