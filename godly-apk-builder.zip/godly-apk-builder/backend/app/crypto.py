import os
import base64
import hashlib
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from app.config import settings

class TokenCryptoError(Exception):
    pass

def _derive_aes_256_key(master_key_str: str) -> bytes:
    if not master_key_str or len(master_key_str.strip()) < 16:
        raise TokenCryptoError("ENCRYPTION_MASTER_KEY is missing or too short in environment.")
    raw = master_key_str.strip()
    if len(raw) == 64:
        try:
            return bytes.fromhex(raw)
        except ValueError:
            pass
    return hashlib.sha256(raw.encode("utf-8")).digest()

def encrypt_github_pat(plain_pat: str, master_key: str = None) -> str:
    if not plain_pat or not isinstance(plain_pat, str):
        raise TokenCryptoError("Token cannot be empty.")
    key = _derive_aes_256_key(master_key or settings.ENCRYPTION_MASTER_KEY)
    aesgcm = AESGCM(key)
    nonce = os.urandom(12)
    ciphertext = aesgcm.encrypt(nonce, plain_pat.encode("utf-8"), associated_data=b"godly-github-pat-v1")
    return base64.urlsafe_b64encode(nonce + ciphertext).decode("ascii")

def decrypt_github_pat(encrypted_payload: str, master_key: str = None) -> str:
    if not encrypted_payload or not isinstance(encrypted_payload, str):
        raise TokenCryptoError("Encrypted payload is empty.")
    try:
        key = _derive_aes_256_key(master_key or settings.ENCRYPTION_MASTER_KEY)
        raw = base64.urlsafe_b64decode(encrypted_payload.encode("ascii"))
        if len(raw) < 28:
            raise TokenCryptoError("Invalid encrypted token payload length.")
        aesgcm = AESGCM(key)
        plain_bytes = aesgcm.decrypt(raw[:12], raw[12:], associated_data=b"godly-github-pat-v1")
        return plain_bytes.decode("utf-8")
    except Exception as exc:
        raise TokenCryptoError("Failed to decrypt GitHub token.") from exc

def mask_github_pat(plain_pat: str) -> str:
    if not plain_pat or len(plain_pat) < 10:
        return "••••••••••••"
    prefix = plain_pat[:4] if plain_pat.startswith(("ghp_", "gho_", "ghu_", "ghs_", "ghr_")) else plain_pat[:6]
    return f"{prefix}{'•' * 16}{plain_pat[-4:]}"
