from typing import Dict, Any, Optional
from fastapi import Request, HTTPException, Header
from app.database import DatabaseStore
from app.build_lock import BuildEngineManager
from app.github_service import GitHubClient
from app.security import hash_session_token, verify_csrf_token

db_store = DatabaseStore()
build_manager = BuildEngineManager(db_store)
github_client = GitHubClient()

SESSION_COOKIE_NAME = "godly_session"

def get_current_session(request: Request) -> Dict[str, Any]:
    raw_token = request.cookies.get(SESSION_COOKIE_NAME)
    if not raw_token:
        raise HTTPException(status_code=401, detail="Vui lòng đăng nhập để tiếp tục sử dụng dịch vụ.")
    token_hash = hash_session_token(raw_token)
    session = db_store.get_session_by_token_hash(token_hash)
    if not session:
        raise HTTPException(status_code=401, detail="Phiên đăng nhập đã hết hạn hoặc không hợp lệ.")
    return session

def get_current_user(request: Request) -> Dict[str, Any]:
    session = get_current_session(request)
    user = db_store.get_user_by_id(session["user_id"])
    if not user:
        raise HTTPException(status_code=401, detail="Tài khoản không tồn tại.")
    return user

def require_csrf(request: Request, x_csrf_token: Optional[str] = Header(default=None)) -> Dict[str, Any]:
    session = get_current_session(request)
    if not x_csrf_token or not verify_csrf_token(session["id"], x_csrf_token):
        raise HTTPException(status_code=403, detail="CSRF token không hợp lệ hoặc bị thiếu.")
    user = db_store.get_user_by_id(session["user_id"])
    if not user:
        raise HTTPException(status_code=401, detail="Tài khoản không tồn tại.")
    return user
