import os
import uuid
import sqlite3
from datetime import datetime, timezone, timedelta
from typing import Any, Dict, List, Optional
from app.config import settings
from app.database import DatabaseStore, BuildLockConflictError, OwnershipViolationError, TERMINAL_BUILD_STATES, utcnow_iso
from app.error_analyzer import analyze_build_failure

STEP_DEFINITIONS = [
    (1, "Upload file ZIP"),
    (2, "Giải nén dự án"),
    (3, "Configure Gradle"),
    (4, "Compile Android"),
    (5, "Đóng gói APK"),
    (6, "Hoàn tất"),
]

STATE_META = {
    "QUEUED":      {"step": 1, "percent": 5,   "estimated": True,  "text": "Đang xếp hàng khởi tạo tiến trình build (Estimated)..."},
    "UPLOADING":   {"step": 1, "percent": 15,  "estimated": True,  "text": "Đang tải file ZIP lên workspace GitHub cô lập (Estimated)..."},
    "EXTRACTING":  {"step": 2, "percent": 30,  "estimated": True,  "text": "Đang kiểm tra bảo mật & giải nén dự án Android (Estimated)..."},
    "CONFIGURING": {"step": 3, "percent": 45,  "estimated": True,  "text": "Đang tự động nhận diện cấu trúc Gradle & Android SDK (Estimated)..."},
    "BUILDING":    {"step": 4, "percent": 72,  "estimated": True,  "text": "Đang biên dịch mã nguồn Android qua GitHub Actions (Estimated)..."},
    "PACKAGING":   {"step": 5, "percent": 90,  "estimated": True,  "text": "Đang đóng gói và xác thực chữ ký file APK (Estimated)..."},
    "SUCCESS":     {"step": 6, "percent": 100, "estimated": False, "text": "Build APK thành công! File APK đã sẵn sàng tải xuống."},
    "FAILED":      {"step": 6, "percent": 100, "estimated": False, "text": "Build thất bại."},
    "CANCELLED":   {"step": 6, "percent": 100, "estimated": False, "text": "Tiến trình build đã bị hủy."},
}

def build_steps_payload(status: str, current_step: int) -> List[Dict[str, Any]]:
    steps = []
    for num, title in STEP_DEFINITIONS:
        if status == "SUCCESS":
            st = "completed"
        elif status == "FAILED":
            st = "completed" if num < current_step else ("failed" if num == current_step else "pending")
        elif status == "CANCELLED":
            st = "completed" if num < current_step else ("cancelled" if num == current_step else "pending")
        else:
            st = "completed" if num < current_step else ("running" if num == current_step else "pending")
        steps.append({"step_number": num, "title": title, "status": st})
    return steps

class BuildEngineManager:
    def __init__(self, db: DatabaseStore):
        self.db = db

    def start_build_atomic(self, user_id: str, repo_full_name: Optional[str] = None, java_version: str = "17") -> Dict[str, Any]:
        build_id = str(uuid.uuid4())
        now_iso = utcnow_iso()
        with self.db._lock:
            conn = self.db._get_conn()
            try:
                conn.execute("BEGIN IMMEDIATE;")
                active = conn.execute("SELECT id FROM builds WHERE user_id = ? AND is_locked = 1", (user_id,)).fetchone()
                if active:
                    raise BuildLockConflictError(active["id"])
                gh = conn.execute("SELECT * FROM github_connections WHERE user_id = ? AND status = 'CONNECTED'", (user_id,)).fetchone()
                if not gh:
                    raise ValueError("Chưa kết nối GitHub Personal Access Token.")
                target_repo = (repo_full_name or gh["selected_repo_full_name"] or "").strip()
                if not target_repo or "/" not in target_repo:
                    raise ValueError("Vui lòng chọn Repository GitHub.")
                if target_repo.split("/")[0].lower() != gh["github_username"].lower():
                    raise OwnershipViolationError("Repository không thuộc tài khoản GitHub đã kết nối.")
                quota = conn.execute("SELECT * FROM upload_quotas WHERE user_id = ?", (user_id,)).fetchone()
                if not quota or not quota["pending_zip_path"]:
                    raise ValueError("Chưa tải lên file ZIP.")
                meta = STATE_META["QUEUED"]
                conn.execute(
                    """INSERT INTO builds (
                        id, user_id, repo_full_name, zip_name, zip_size, zip_sha256, zip_storage_path,
                        apk_name, status, progress_percent, is_estimated_progress, current_step,
                        status_text, is_locked, detected_java_version, started_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'QUEUED', ?, ?, ?, ?, 1, ?, ?, ?)""",
                    (
                        build_id, user_id, target_repo, quota["pending_zip_name"], quota["pending_zip_size"],
                        quota["pending_zip_sha256"], quota["pending_zip_path"], quota["pending_apk_name"],
                        meta["percent"], int(meta["estimated"]), meta["step"], meta["text"], java_version, now_iso, now_iso
                    )
                )
                conn.execute("COMMIT;")
            except Exception:
                conn.execute("ROLLBACK;")
                raise
            finally:
                self.db._close_if_transient(conn)
        return self.get_build_status(user_id, build_id)

    def complete_build_with_verified_apk(self, build_id: str, apk_storage_path: str, apk_size: int, apk_sha256: str, apk_version: str = "1.0-debug") -> Dict[str, Any]:
        now_dt = datetime.now(timezone.utc)
        now_iso = now_dt.isoformat()
        exp_iso = (now_dt + timedelta(days=settings.ARTIFACT_RETENTION_DAYS)).isoformat()
        with self.db._lock:
            conn = self.db._get_conn()
            try:
                conn.execute("BEGIN IMMEDIATE;")
                row = conn.execute("SELECT * FROM builds WHERE id = ?", (build_id,)).fetchone()
                conn.execute(
                    "INSERT OR REPLACE INTO build_artifacts (id, build_id, user_id, apk_name, apk_size, apk_sha256, apk_version, storage_path, is_available, expires_at, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)",
                    (str(uuid.uuid4()), build_id, row["user_id"], row["apk_name"], apk_size, apk_sha256, apk_version, apk_storage_path, exp_iso, now_iso)
                )
                conn.execute(
                    "UPDATE builds SET status='SUCCESS', progress_percent=100, is_estimated_progress=0, current_step=6, status_text=?, is_locked=0, finished_at=?, duration_seconds=10, updated_at=? WHERE id=?",
                    (STATE_META["SUCCESS"]["text"], now_iso, now_iso, build_id)
                )
                conn.execute("COMMIT;")
                user_id = row["user_id"]
            except Exception:
                conn.execute("ROLLBACK;")
                raise
            finally:
                self.db._close_if_transient(conn)
        return self.get_build_status(user_id, build_id)

    def cancel_build(self, user_id: str, build_id: str) -> Dict[str, Any]:
        now_iso = utcnow_iso()
        with self.db._lock:
            conn = self.db._get_conn()
            try:
                conn.execute("BEGIN IMMEDIATE;")
                row = conn.execute("SELECT * FROM builds WHERE id = ?", (build_id,)).fetchone()
                if not row:
                    raise KeyError("Không tìm thấy build.")
                if row["user_id"] != user_id:
                    raise OwnershipViolationError("Không có quyền hủy build của người khác.")
                conn.execute("UPDATE builds SET status='CANCELLED', is_locked=0, finished_at=?, updated_at=? WHERE id=?", (now_iso, now_iso, build_id))
                conn.execute("COMMIT;")
            except Exception:
                conn.execute("ROLLBACK;")
                raise
            finally:
                self.db._close_if_transient(conn)
        return self.get_build_status(user_id, build_id)

    def get_build_status(self, user_id: str, build_id: str) -> Dict[str, Any]:
        with self.db._lock:
            conn = self.db._get_conn()
            try:
                row = conn.execute("SELECT * FROM builds WHERE id = ?", (build_id,)).fetchone()
                if not row:
                    raise KeyError("Không tìm thấy build.")
                if row["user_id"] != user_id:
                    raise OwnershipViolationError("Không có quyền xem build của người khác.")
                art = conn.execute("SELECT * FROM build_artifacts WHERE build_id = ? AND user_id = ? AND is_available = 1", (build_id, user_id)).fetchone()
                art_ok = bool(art and os.path.isfile(art["storage_path"]))
                return {
                    "build_id": row["id"],
                    "user_id": row["user_id"],
                    "repo_full_name": row["repo_full_name"],
                    "zip_name": row["zip_name"],
                    "zip_size": row["zip_size"],
                    "apk_name": row["apk_name"],
                    "status": row["status"],
                    "progress_percent": int(row["progress_percent"]),
                    "is_estimated_progress": bool(row["is_estimated_progress"]),
                    "current_step": int(row["current_step"]),
                    "status_text": row["status_text"],
                    "is_locked": bool(row["is_locked"]),
                    "started_at": row["started_at"],
                    "finished_at": row["finished_at"],
                    "duration_seconds": int(row["duration_seconds"] or 0),
                    "steps": build_steps_payload(row["status"], int(row["current_step"])),
                    "error_code": row["error_code"],
                    "error_summary_vi": row["error_summary_vi"],
                    "error_suggestion_vi": row["error_suggestion_vi"],
                    "artifact_available": art_ok and row["status"] == "SUCCESS",
                    "apk_size": art["apk_size"] if art_ok else None,
                    "apk_version": art["apk_version"] if art_ok else None,
                }
            finally:
                self.db._close_if_transient(conn)

    def get_verified_artifact_for_download(self, user_id: str, build_id: str) -> Dict[str, Any]:
        with self.db._lock:
            conn = self.db._get_conn()
            try:
                row = conn.execute("SELECT * FROM builds WHERE id = ?", (build_id,)).fetchone()
                if not row:
                    raise KeyError("Không tìm thấy build.")
                if row["user_id"] != user_id:
                    raise OwnershipViolationError("Không có quyền tải APK của người khác.")
                if row["status"] != "SUCCESS":
                    raise ValueError("Build chưa thành công.")
                art = conn.execute("SELECT * FROM build_artifacts WHERE build_id = ? AND user_id = ?", (build_id, user_id)).fetchone()
                if not art or not os.path.isfile(art["storage_path"]):
                    raise FileNotFoundError("File APK không tồn tại.")
                return dict(art)
            finally:
                self.db._close_if_transient(conn)
