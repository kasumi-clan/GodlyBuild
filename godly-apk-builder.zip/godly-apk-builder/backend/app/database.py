import os
import uuid
import sqlite3
import threading
from datetime import datetime, timezone, timedelta
from typing import Any, Dict, Optional
from app.config import settings

TERMINAL_BUILD_STATES = {"SUCCESS", "FAILED", "CANCELLED"}

def utcnow_iso() -> str:
    return datetime.now(timezone.utc).isoformat()

class DatabaseConstraintError(Exception):
    pass

class BuildLockConflictError(Exception):
    def __init__(self, active_build_id: str, message_vi: str = "Bạn đang có một tiến trình build đang chạy."):
        super().__init__(message_vi)
        self.active_build_id = active_build_id
        self.message_vi = message_vi

class OwnershipViolationError(Exception):
    pass

class DatabaseStore:
    def __init__(self, sqlite_path: Optional[str] = None):
        if sqlite_path is None:
            os.makedirs(settings.STORAGE_ROOT, exist_ok=True)
            sqlite_path = os.path.join(settings.STORAGE_ROOT, "godly_apk_builder.sqlite3")
        self.sqlite_path = sqlite_path
        self._lock = threading.RLock()
        self._persistent_conn = None
        if sqlite_path == ":memory:":
            self._persistent_conn = sqlite3.connect(":memory:", check_same_thread=False, isolation_level=None)
            self._persistent_conn.row_factory = sqlite3.Row
            self._persistent_conn.execute("PRAGMA foreign_keys = ON;")
        self._init_schema()

    def _get_conn(self) -> sqlite3.Connection:
        if self._persistent_conn is not None:
            return self._persistent_conn
        conn = sqlite3.connect(self.sqlite_path, timeout=30.0, check_same_thread=False, isolation_level=None)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON;")
        return conn

    def _close_if_transient(self, conn: sqlite3.Connection) -> None:
        if self._persistent_conn is None:
            conn.close()

    def _init_schema(self) -> None:
        with self._lock:
            conn = self._get_conn()
            try:
                conn.executescript("""
                CREATE TABLE IF NOT EXISTS users (
                    id TEXT PRIMARY KEY,
                    username TEXT NOT NULL UNIQUE,
                    email TEXT NOT NULL UNIQUE,
                    password_hash TEXT NOT NULL,
                    is_admin INTEGER NOT NULL DEFAULT 0,
                    terms_accepted INTEGER NOT NULL DEFAULT 1,
                    reset_token_hash TEXT,
                    reset_token_expires_at TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS sessions (
                    id TEXT PRIMARY KEY,
                    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                    token_hash TEXT NOT NULL UNIQUE,
                    csrf_token TEXT NOT NULL,
                    ip_address TEXT,
                    user_agent TEXT,
                    remember_me INTEGER NOT NULL DEFAULT 0,
                    expires_at TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS github_connections (
                    id TEXT PRIMARY KEY,
                    user_id TEXT NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
                    github_username TEXT NOT NULL,
                    github_user_id TEXT,
                    avatar_url TEXT,
                    encrypted_pat TEXT NOT NULL,
                    masked_pat TEXT NOT NULL,
                    scopes TEXT,
                    status TEXT NOT NULL DEFAULT 'CONNECTED',
                    selected_repo_full_name TEXT,
                    connected_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS repositories (
                    id TEXT PRIMARY KEY,
                    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                    github_connection_id TEXT NOT NULL REFERENCES github_connections(id) ON DELETE CASCADE,
                    repo_name TEXT NOT NULL,
                    full_name TEXT NOT NULL,
                    private INTEGER NOT NULL DEFAULT 1,
                    default_branch TEXT NOT NULL DEFAULT 'main',
                    is_active INTEGER NOT NULL DEFAULT 1,
                    created_at TEXT NOT NULL,
                    UNIQUE(user_id, full_name)
                );
                CREATE TABLE IF NOT EXISTS upload_quotas (
                    id TEXT PRIMARY KEY,
                    user_id TEXT NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
                    max_uploads INTEGER NOT NULL DEFAULT 10,
                    used_uploads INTEGER NOT NULL DEFAULT 0,
                    reset_policy TEXT NOT NULL DEFAULT 'manual',
                    pending_zip_id TEXT,
                    pending_zip_name TEXT,
                    pending_zip_path TEXT,
                    pending_zip_size INTEGER,
                    pending_zip_sha256 TEXT,
                    pending_apk_name TEXT,
                    updated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS builds (
                    id TEXT PRIMARY KEY,
                    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                    repository_id TEXT,
                    repo_full_name TEXT NOT NULL,
                    zip_name TEXT NOT NULL,
                    zip_size INTEGER NOT NULL,
                    zip_sha256 TEXT NOT NULL,
                    zip_storage_path TEXT NOT NULL,
                    apk_name TEXT NOT NULL,
                    status TEXT NOT NULL,
                    progress_percent INTEGER NOT NULL DEFAULT 0,
                    is_estimated_progress INTEGER NOT NULL DEFAULT 1,
                    current_step INTEGER NOT NULL DEFAULT 1,
                    status_text TEXT NOT NULL,
                    is_locked INTEGER NOT NULL DEFAULT 1,
                    github_run_id TEXT,
                    github_branch TEXT,
                    detected_module TEXT,
                    detected_java_version TEXT,
                    error_code TEXT,
                    error_summary_vi TEXT,
                    error_suggestion_vi TEXT,
                    started_at TEXT NOT NULL,
                    finished_at TEXT,
                    duration_seconds INTEGER,
                    updated_at TEXT NOT NULL
                );
                CREATE UNIQUE INDEX IF NOT EXISTS uq_builds_one_active_lock_per_user ON builds(user_id) WHERE is_locked = 1;
                CREATE TABLE IF NOT EXISTS build_logs (
                    id TEXT PRIMARY KEY,
                    build_id TEXT NOT NULL REFERENCES builds(id) ON DELETE CASCADE,
                    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                    step_number INTEGER NOT NULL,
                    step_name TEXT NOT NULL,
                    log_level TEXT NOT NULL DEFAULT 'INFO',
                    message TEXT NOT NULL,
                    admin_diagnostics TEXT,
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS build_artifacts (
                    id TEXT PRIMARY KEY,
                    build_id TEXT NOT NULL UNIQUE REFERENCES builds(id) ON DELETE CASCADE,
                    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                    apk_name TEXT NOT NULL,
                    apk_size INTEGER NOT NULL,
                    apk_sha256 TEXT NOT NULL,
                    apk_version TEXT,
                    storage_path TEXT NOT NULL,
                    github_artifact_id TEXT,
                    is_available INTEGER NOT NULL DEFAULT 1,
                    expires_at TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS audit_logs (
                    id TEXT PRIMARY KEY,
                    user_id TEXT,
                    action TEXT NOT NULL,
                    resource_type TEXT NOT NULL,
                    resource_id TEXT,
                    ip_address TEXT,
                    details TEXT,
                    created_at TEXT NOT NULL
                );
                """)
            finally:
                self._close_if_transient(conn)

    def log_audit(self, user_id: Optional[str], action: str, resource_type: str, resource_id: Optional[str] = None, ip_address: Optional[str] = None, details: Optional[str] = None) -> None:
        with self._lock:
            conn = self._get_conn()
            try:
                conn.execute("BEGIN IMMEDIATE;")
                conn.execute(
                    "INSERT INTO audit_logs (id, user_id, action, resource_type, resource_id, ip_address, details, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                    (str(uuid.uuid4()), user_id, action, resource_type, resource_id, ip_address, details, utcnow_iso())
                )
                conn.execute("COMMIT;")
            except Exception:
                conn.execute("ROLLBACK;")
            finally:
                self._close_if_transient(conn)

    def create_user(self, username: str, email: str, password_hash: str, terms_accepted: bool = True, is_admin: bool = False) -> Dict[str, Any]:
        now = utcnow_iso()
        user_id = str(uuid.uuid4())
        with self._lock:
            conn = self._get_conn()
            try:
                conn.execute("BEGIN IMMEDIATE;")
                dup = conn.execute("SELECT id FROM users WHERE lower(username)=lower(?) OR lower(email)=lower(?)", (username, email)).fetchone()
                if dup:
                    raise DatabaseConstraintError("Username hoặc Email đã tồn tại.")
                conn.execute(
                    "INSERT INTO users (id, username, email, password_hash, is_admin, terms_accepted, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                    (user_id, username, email.lower(), password_hash, int(is_admin), int(terms_accepted), now, now)
                )
                conn.execute(
                    "INSERT INTO upload_quotas (id, user_id, max_uploads, used_uploads, reset_policy, updated_at) VALUES (?, ?, ?, 0, ?, ?)",
                    (str(uuid.uuid4()), user_id, settings.DEFAULT_UPLOAD_QUOTA, settings.QUOTA_RESET_POLICY, now)
                )
                conn.execute("COMMIT;")
            except Exception:
                conn.execute("ROLLBACK;")
                raise
            finally:
                self._close_if_transient(conn)
        return self.get_user_by_id(user_id)

    def get_user_by_id(self, user_id: str) -> Optional[Dict[str, Any]]:
        with self._lock:
            conn = self._get_conn()
            try:
                row = conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
                return dict(row) if row else None
            finally:
                self._close_if_transient(conn)

    def get_user_by_identifier(self, identifier: str) -> Optional[Dict[str, Any]]:
        with self._lock:
            conn = self._get_conn()
            try:
                row = conn.execute("SELECT * FROM users WHERE lower(username)=lower(?) OR lower(email)=lower(?)", (identifier, identifier)).fetchone()
                return dict(row) if row else None
            finally:
                self._close_if_transient(conn)

    def upsert_github_connection(self, user_id: str, github_username: str, encrypted_pat: str, masked_pat: str, github_user_id: str = None, avatar_url: str = None, scopes: str = None, selected_repo_full_name: str = None) -> Dict[str, Any]:
        now = utcnow_iso()
        with self._lock:
            conn = self._get_conn()
            try:
                conn.execute("BEGIN IMMEDIATE;")
                ex = conn.execute("SELECT id FROM github_connections WHERE user_id = ?", (user_id,)).fetchone()
                if ex:
                    conn.execute(
                        "UPDATE github_connections SET github_username=?, encrypted_pat=?, masked_pat=?, avatar_url=?, scopes=?, status='CONNECTED', selected_repo_full_name=COALESCE(?, selected_repo_full_name), updated_at=? WHERE user_id=?",
                        (github_username, encrypted_pat, masked_pat, avatar_url, scopes, selected_repo_full_name, now, user_id)
                    )
                else:
                    conn.execute(
                        "INSERT INTO github_connections (id, user_id, github_username, github_user_id, avatar_url, encrypted_pat, masked_pat, scopes, status, selected_repo_full_name, connected_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'CONNECTED', ?, ?, ?)",
                        (str(uuid.uuid4()), user_id, github_username, github_user_id, avatar_url, encrypted_pat, masked_pat, scopes, selected_repo_full_name, now, now)
                    )
                conn.execute("COMMIT;")
            except Exception:
                conn.execute("ROLLBACK;")
                raise
            finally:
                self._close_if_transient(conn)
        return self.get_github_connection(user_id)

    def get_github_connection(self, user_id: str, include_encrypted: bool = False) -> Optional[Dict[str, Any]]:
        with self._lock:
            conn = self._get_conn()
            try:
                row = conn.execute("SELECT * FROM github_connections WHERE user_id = ?", (user_id,)).fetchone()
                if not row:
                    return None
                d = dict(row)
                if not include_encrypted:
                    d.pop("encrypted_pat", None)
                return d
            finally:
                self._close_if_transient(conn)

    def get_upload_quota(self, user_id: str) -> Dict[str, Any]:
        with self._lock:
            conn = self._get_conn()
            try:
                row = conn.execute("SELECT * FROM upload_quotas WHERE user_id = ?", (user_id,)).fetchone()
                d = dict(row)
                d["remaining_uploads"] = max(0, d["max_uploads"] - d["used_uploads"])
                return d
            finally:
                self._close_if_transient(conn)

    def record_pending_zip_upload(self, user_id: str, zip_id: str, zip_name: str, zip_path: str, zip_size: int, zip_sha256: str, apk_name: str) -> Dict[str, Any]:
        now = utcnow_iso()
        with self._lock:
            conn = self._get_conn()
            try:
                conn.execute("BEGIN IMMEDIATE;")
                active = conn.execute("SELECT id FROM builds WHERE user_id = ? AND is_locked = 1", (user_id,)).fetchone()
                if active:
                    raise BuildLockConflictError(active["id"], "Không thể thay ZIP khi đang có build chạy.")
                q = conn.execute("SELECT * FROM upload_quotas WHERE user_id = ?", (user_id,)).fetchone()
                if q["used_uploads"] >= q["max_uploads"]:
                    raise PermissionError("Đã hết hạn mức tải lên 10/10 lượt.")
                conn.execute(
                    "UPDATE upload_quotas SET used_uploads = used_uploads + 1, pending_zip_id=?, pending_zip_name=?, pending_zip_path=?, pending_zip_size=?, pending_zip_sha256=?, pending_apk_name=?, updated_at=? WHERE user_id=?",
                    (zip_id, zip_name, zip_path, zip_size, zip_sha256, apk_name, now, user_id)
                )
                conn.execute("COMMIT;")
            except Exception:
                conn.execute("ROLLBACK;")
                raise
            finally:
                self._close_if_transient(conn)
        return self.get_upload_quota(user_id)
