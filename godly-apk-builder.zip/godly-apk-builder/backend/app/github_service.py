import json
from dataclasses import dataclass
from typing import Callable, Dict, Optional
from app.security import mask_secrets_in_text

GITHUB_API_BASE = "https://api.github.com"

class GitHubServiceError(Exception):
    def __init__(self, code: str, message_vi: str, status_code: int = 400):
        super().__init__(message_vi)
        self.code = code
        self.message_vi = message_vi
        self.status_code = status_code

@dataclass
class VerifiedGitHubProfile:
    github_username: str
    github_user_id: str
    avatar_url: str
    scopes: str
    token_type: str

class GitHubClient:
    def __init__(self, transport: Optional[Callable] = None):
        self.transport = transport

    def verify_pat_and_get_profile(self, pat: str, expected_username: Optional[str] = None) -> VerifiedGitHubProfile:
        if not pat or len(pat.strip()) < 15:
            raise GitHubServiceError("GITHUB_TOKEN_INVALID", "Token không hợp lệ.", 401)
        status, headers, raw = self.transport("GET", f"{GITHUB_API_BASE}/user", {"Authorization": f"Bearer {pat}"}, None, 20)
        if status == 401:
            raise GitHubServiceError("GITHUB_TOKEN_INVALID", "GitHub Token không hợp lệ hoặc đã bị thu hồi.", 401)
        if status == 403:
            raise GitHubServiceError("PERMISSION_DENIED", "GitHub Token bị từ chối quyền truy cập.", 403)
        data = json.loads(raw.decode("utf-8"))
        return VerifiedGitHubProfile(
            github_username=data.get("login", ""),
            github_user_id=str(data.get("id", "")),
            avatar_url=data.get("avatar_url", ""),
            scopes=headers.get("x-oauth-scopes", "repo,workflow"),
            token_type="classic",
        )
