import os
from dataclasses import dataclass, field
from typing import List

@dataclass
class Settings:
    APP_NAME: str = field(default_factory=lambda: os.getenv("APP_NAME", "Godly APK Builder"))
    APP_ENV: str = field(default_factory=lambda: os.getenv("APP_ENV", "production"))
    FRONTEND_URL: str = field(default_factory=lambda: os.getenv("FRONTEND_URL", "http://localhost:5173"))
    BACKEND_URL: str = field(default_factory=lambda: os.getenv("BACKEND_URL", "http://localhost:8000"))
    DATABASE_URL: str = field(default_factory=lambda: os.getenv(
        "DATABASE_URL",
        "postgresql+psycopg2://godly_user:CHANGE_ME_DB_PASSWORD@localhost:5432/godly_apk_builder"
    ))
    ENCRYPTION_MASTER_KEY: str = field(default_factory=lambda: os.getenv(
        "ENCRYPTION_MASTER_KEY",
        "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
    ))
    SESSION_SECRET_KEY: str = field(default_factory=lambda: os.getenv(
        "SESSION_SECRET_KEY",
        "godly_session_secret_key_change_in_prod_9876543210abcdef"
    ))
    CSRF_SECRET_KEY: str = field(default_factory=lambda: os.getenv(
        "CSRF_SECRET_KEY",
        "godly_csrf_secret_key_change_in_prod_0123456789abcdef"
    ))
    COOKIE_SECURE: bool = field(default_factory=lambda: os.getenv("COOKIE_SECURE", "true").lower() == "true")
    COOKIE_SAMESITE: str = field(default_factory=lambda: os.getenv("COOKIE_SAMESITE", "lax"))
    SESSION_EXPIRE_HOURS: int = field(default_factory=lambda: int(os.getenv("SESSION_EXPIRE_HOURS", "24")))
    SESSION_REMEMBER_DAYS: int = field(default_factory=lambda: int(os.getenv("SESSION_REMEMBER_DAYS", "30")))
    MAX_UPLOAD_MB: int = field(default_factory=lambda: int(os.getenv("MAX_UPLOAD_MB", "25")))
    MAX_UNPACKED_MB: int = field(default_factory=lambda: int(os.getenv("MAX_UNPACKED_MB", "250")))
    DEFAULT_UPLOAD_QUOTA: int = field(default_factory=lambda: int(os.getenv("DEFAULT_UPLOAD_QUOTA", "10")))
    QUOTA_RESET_POLICY: str = field(default_factory=lambda: os.getenv("QUOTA_RESET_POLICY", "manual"))
    BUILD_TIMEOUT_SECONDS: int = field(default_factory=lambda: int(os.getenv("BUILD_TIMEOUT_SECONDS", "1200")))
    STALE_LOCK_SECONDS: int = field(default_factory=lambda: int(os.getenv("STALE_LOCK_SECONDS", "1500")))
    ARTIFACT_RETENTION_DAYS: int = field(default_factory=lambda: int(os.getenv("ARTIFACT_RETENTION_DAYS", "7")))
    SMTP_HOST: str = field(default_factory=lambda: os.getenv("SMTP_HOST", ""))
    SMTP_PORT: int = field(default_factory=lambda: int(os.getenv("SMTP_PORT", "587")))
    SMTP_USE_TLS: bool = field(default_factory=lambda: os.getenv("SMTP_USE_TLS", "true").lower() == "true")
    SMTP_USER: str = field(default_factory=lambda: os.getenv("SMTP_USER", ""))
    SMTP_PASSWORD: str = field(default_factory=lambda: os.getenv("SMTP_PASSWORD", ""))
    SMTP_FROM_EMAIL: str = field(default_factory=lambda: os.getenv("SMTP_FROM_EMAIL", "noreply@godly-apk-builder.local"))
    SMTP_FROM_NAME: str = field(default_factory=lambda: os.getenv("SMTP_FROM_NAME", "Godly APK Builder"))
    STORAGE_ROOT: str = field(default_factory=lambda: os.getenv("STORAGE_ROOT", "/tmp/godly-apk-storage"))

    @property
    def cors_origins_list(self) -> List[str]:
        raw = os.getenv("CORS_ORIGINS", self.FRONTEND_URL)
        return [o.strip() for o in raw.split(",") if o.strip()]

    @property
    def max_upload_bytes(self) -> int:
        return self.MAX_UPLOAD_MB * 1024 * 1024

    @property
    def max_unpacked_bytes(self) -> int:
        return self.MAX_UNPACKED_MB * 1024 * 1024

settings = Settings()
