import re
from dataclasses import dataclass
from typing import List, Optional
from app.security import mask_secrets_in_text

@dataclass
class BuildErrorAnalysis:
    error_code: str
    category_vi: str
    cause_vi: str
    suggestion_vi: str
    can_retry: bool
    user_safe_excerpt: str
    admin_diagnostics: str

_RULES = [
    ("INVALID_ZIP", [r"ERROR_CODE=INVALID_ZIP", r"Zip Slip"], "File ZIP không hợp lệ", "File ZIP hỏng hoặc chứa đường dẫn nguy hiểm.", "Nén lại dự án chuẩn .zip dưới 25 MB.", False),
    ("MISSING_SETTINGS_GRADLE", [r"ERROR_CODE=MISSING_SETTINGS_GRADLE", r"Missing settings\.gradle"], "Thiếu tệp settings.gradle", "Dự án thiếu tệp settings.gradle hoặc settings.gradle.kts.", "Thêm settings.gradle vào gốc dự án.", False),
    ("NOT_ANDROID_PROJECT", [r"ERROR_CODE=NOT_ANDROID_PROJECT"], "Không phải dự án Android", "File ZIP không chứa cấu trúc Android Gradle.", "Kiểm tra lại thư mục dự án trước khi nén.", False),
    ("MISSING_APP_MODULE", [r"ERROR_CODE=MISSING_APP_MODULE"], "Thiếu module ứng dụng (:app)", "Không tìm thấy plugin com.android.application.", "Kiểm tra app/build.gradle.", False),
    ("JAVA_INCOMPATIBILITY", [r"UnsupportedClassVersionError", r"JvmTarget"], "Không tương thích phiên bản Java", "Phiên bản JDK không khớp cấu hình Gradle.", "Đồng bộ compileOptions về JDK 17.", True),
    ("GRADLE_INCOMPATIBILITY", [r"Minimum supported Gradle version"], "Không tương thích phiên bản Gradle", "Gradle wrapper không khớp với AGP.", "Cập nhật gradle-wrapper.properties.", True),
    ("ANDROID_SDK_MISSING", [r"SDK location not found", r"compileSdkVersion .* is not found"], "Thiếu Android SDK", "Thiếu platform SDK yêu cầu.", "Đặt compileSdk 34 trong app/build.gradle.", True),
    ("DEPENDENCY_RESOLUTION_FAILURE", [r"Could not resolve all", r"Failed to resolve:"], "Lỗi tải thư viện phụ thuộc", "Không tải được dependency từ Maven/Google.", "Kiểm tra tên thư viện và repositories.", True),
    ("GITHUB_QUOTA_EXCEEDED", [r"API rate limit exceeded", r"billing"], "Vượt hạn mức GitHub Actions", "Tài khoản GitHub hết phút chạy Actions.", "Kiểm tra Billing trên GitHub.", True),
    ("GITHUB_TOKEN_INVALID", [r"Bad credentials", r"401 Unauthorized", r"GITHUB_TOKEN_INVALID"], "GitHub Token không hợp lệ", "Token đã hết hạn hoặc bị thu hồi.", "Tạo PAT mới và nhấn Reconnect.", False),
    ("PERMISSION_DENIED", [r"403 Forbidden", r"PERMISSION_DENIED"], "Thiếu quyền truy cập GitHub", "PAT thiếu quyền repo hoặc workflow.", "Cấp quyền repo và workflow cho PAT.", False),
    ("ARTIFACT_MISSING", [r"ERROR_CODE=ARTIFACT_MISSING"], "Không tìm thấy file APK", "Build kết thúc nhưng không có file APK.", "Kiểm tra cấu hình assembleDebug.", True),
    ("BUILD_TIMEOUT", [r"BUILD_TIMEOUT", r"Timed out"], "Quá thời gian build (Timeout)", "Build vượt quá 20 phút.", "Nhấn Retry Build để thử lại.", True),
]

def analyze_build_failure(raw_log: str, explicit_error_code: Optional[str] = None, extra_secrets: Optional[List[str]] = None) -> BuildErrorAnalysis:
    scrubbed = mask_secrets_in_text(raw_log or "", extra_secrets=extra_secrets)
    for code, pats, cat, cause, sugg, retry in _RULES:
        if explicit_error_code == code or any(re.search(p, scrubbed, re.I) for p in pats):
            return BuildErrorAnalysis(code, cat, cause, sugg, retry, scrubbed[:500], scrubbed[-4000:])
    return BuildErrorAnalysis(
        "BUILD_FAILED",
        "Lỗi biên dịch mã nguồn Android",
        "Trình biên dịch Gradle/Kotlin/Java báo lỗi cú pháp hoặc tài nguyên.",
        "Kiểm tra mã nguồn và nhấn Retry Build.",
        True,
        scrubbed[:500],
        scrubbed[-4000:],
    )
