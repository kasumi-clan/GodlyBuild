import json
import asyncio
from pathlib import Path
from fastapi import APIRouter, HTTPException, Depends
from fastapi.responses import StreamingResponse, FileResponse
from app.schemas import StartBuildRequest
from app.database import BuildLockConflictError, OwnershipViolationError, TERMINAL_BUILD_STATES
from app.crypto import decrypt_github_pat
from app.github_service import GitHubServiceError
from app.deps import db_store, build_manager, github_client, get_current_user, require_csrf

router = APIRouter(prefix="/api", tags=["build", "apk", "history"])

WORKFLOW_TEMPLATE_PATH = Path(__file__).resolve().parents[3] / ".github" / "workflows" / "build.yml"

@router.post("/build/start")
def start_build(payload: StartBuildRequest, user=Depends(require_csrf)):
    try:
        build_state = build_manager.start_build_atomic(
            user_id=user["id"],
            repo_full_name=payload.repo_full_name,
            java_version=payload.java_version,
        )
    except BuildLockConflictError as exc:
        raise HTTPException(status_code=409, detail=exc.message_vi)
    except OwnershipViolationError as exc:
        raise HTTPException(status_code=403, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

    build_id = build_state["build_id"]
    gh = db_store.get_github_connection(user["id"], include_encrypted=True)
    quota = db_store.get_upload_quota(user["id"])

    try:
        pat = decrypt_github_pat(gh["encrypted_pat"])
        build_manager.transition_build_state(
            build_id=build_id,
            new_status="UPLOADING",
            log_message="Đang đẩy workflow bảo mật và file ZIP phiên hiện tại (ZIP 1) lên GitHub Repository riêng...",
        )
        if WORKFLOW_TEMPLATE_PATH.is_file():
            wf_bytes = WORKFLOW_TEMPLATE_PATH.read_bytes()
            github_client.put_repository_file(
                pat=pat,
                repo_full_name=build_state["repo_full_name"],
                path_in_repo=".github/workflows/build.yml",
                content_bytes=wf_bytes,
                commit_message=f"chore(ci): update Godly APK Builder workflow [{build_id}]",
            )

        with open(quota["pending_zip_path"], "rb") as zf:
            zip_bytes = zf.read()

        zip_repo_path = f"workspaces/{user['id']}/{build_id}/{build_state['zip_name']}"
        github_client.put_repository_file(
            pat=pat,
            repo_full_name=build_state["repo_full_name"],
            path_in_repo=zip_repo_path,
            content_bytes=zip_bytes,
            commit_message=f"build(zip): upload session ZIP 1 for build {build_id}",
        )

        github_client.trigger_build_workflow(
            pat=pat,
            repo_full_name=build_state["repo_full_name"],
            branch="main",
            build_id=build_id,
            user_id=user["id"],
            zip_repo_path=zip_repo_path,
            apk_basename=build_state["apk_name"],
            java_version=payload.java_version,
        )

        updated = build_manager.transition_build_state(
            build_id=build_id,
            new_status="BUILDING",
            log_message="Đã kích hoạt GitHub Actions workflow. Đang biên dịch APK...",
        )
        return updated
    except GitHubServiceError as exc:
        failed = build_manager.fail_build(
            build_id=build_id,
            raw_log=exc.message_vi,
            explicit_error_code=exc.code,
        )
        return failed

@router.get("/build/{build_id}/status")
def get_build_status(build_id: str, user=Depends(get_current_user)):
    try:
        return build_manager.get_build_status(user["id"], build_id)
    except OwnershipViolationError as exc:
        raise HTTPException(status_code=403, detail=str(exc))
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc))

@router.get("/build/{build_id}/stream")
async def stream_build_progress(build_id: str, user=Depends(get_current_user)):
    try:
        build_manager.get_build_status(user["id"], build_id)
    except OwnershipViolationError as exc:
        raise HTTPException(status_code=403, detail=str(exc))
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc))

    async def event_generator():
        while True:
            state = build_manager.get_build_status(user["id"], build_id)
            yield f"data: {json.dumps(state, ensure_ascii=False)}\n\n"
            if state["status"] in TERMINAL_BUILD_STATES:
                break
            await asyncio.sleep(2)

    return StreamingResponse(event_generator(), media_type="text/event-stream")

@router.post("/build/{build_id}/cancel")
def cancel_build(build_id: str, user=Depends(require_csrf)):
    try:
        current = build_manager.get_build_status(user["id"], build_id)
        if current.get("github_run_id"):
            gh = db_store.get_github_connection(user["id"], include_encrypted=True)
            if gh:
                pat = decrypt_github_pat(gh["encrypted_pat"])
                github_client.cancel_workflow_run(pat, current["repo_full_name"], current["github_run_id"])
        return build_manager.cancel_build(user["id"], build_id)
    except OwnershipViolationError as exc:
        raise HTTPException(status_code=403, detail=str(exc))
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc))

@router.post("/build/{build_id}/retry")
def retry_build(build_id: str, user=Depends(require_csrf)):
    try:
        return build_manager.retry_build(user["id"], build_id)
    except OwnershipViolationError as exc:
        raise HTTPException(status_code=403, detail=str(exc))
    except BuildLockConflictError as exc:
        raise HTTPException(status_code=409, detail=exc.message_vi)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

@router.get("/build/{build_id}/logs")
def get_build_logs(build_id: str, user=Depends(get_current_user)):
    try:
        logs = build_manager.get_build_logs(user["id"], build_id, is_admin=bool(user.get("is_admin")))
        return {"build_id": build_id, "logs": logs}
    except OwnershipViolationError as exc:
        raise HTTPException(status_code=403, detail=str(exc))
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc))

@router.get("/apk/{build_id}/info")
def get_apk_info(build_id: str, user=Depends(get_current_user)):
    try:
        art = build_manager.get_verified_artifact_for_download(user["id"], build_id)
        return {
            "build_id": build_id,
            "apk_name": art["apk_name"],
            "apk_size": art["apk_size"],
            "apk_version": art["apk_version"],
            "apk_sha256": art["apk_sha256"],
            "expires_at": art["expires_at"],
        }
    except OwnershipViolationError as exc:
        raise HTTPException(status_code=403, detail=str(exc))
    except (ValueError, FileNotFoundError, KeyError) as exc:
        raise HTTPException(status_code=404, detail=str(exc))

@router.get("/apk/{build_id}/download")
def download_apk(build_id: str, user=Depends(get_current_user)):
    try:
        art = build_manager.get_verified_artifact_for_download(user["id"], build_id)
        db_store.log_audit(user["id"], "APK_DOWNLOAD", "build_artifact", art["id"])
        return FileResponse(
            path=art["storage_path"],
            filename=art["apk_name"],
            media_type="application/vnd.android.package-archive",
        )
    except OwnershipViolationError as exc:
        raise HTTPException(status_code=403, detail=str(exc))
    except (ValueError, FileNotFoundError, KeyError) as exc:
        raise HTTPException(status_code=404, detail=str(exc))

@router.get("/history")
def list_history(user=Depends(get_current_user)):
    return {"builds": build_manager.list_user_builds(user["id"])}

@router.get("/history/{build_id}")
def get_history_detail(build_id: str, user=Depends(get_current_user)):
    try:
        status = build_manager.get_build_status(user["id"], build_id)
        logs = build_manager.get_build_logs(user["id"], build_id, is_admin=bool(user.get("is_admin")))
        return {"build": status, "logs": logs}
    except OwnershipViolationError as exc:
        raise HTTPException(status_code=403, detail=str(exc))
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
