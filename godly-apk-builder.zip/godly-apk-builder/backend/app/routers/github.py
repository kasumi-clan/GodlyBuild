from fastapi import APIRouter, HTTPException, Depends
from app.schemas import GitHubConnectRequest, CreateRepoRequest, SelectRepoRequest
from app.crypto import encrypt_github_pat, decrypt_github_pat, mask_github_pat
from app.github_service import GitHubServiceError
from app.database import OwnershipViolationError
from app.deps import db_store, github_client, get_current_user, require_csrf

router = APIRouter(prefix="/api/github", tags=["github"])

@router.post("/connect")
def connect_github(payload: GitHubConnectRequest, user=Depends(require_csrf)):
    try:
        profile = github_client.verify_pat_and_get_profile(
            pat=payload.personal_access_token,
            expected_username=payload.github_username,
        )
    except GitHubServiceError as exc:
        raise HTTPException(status_code=exc.status_code, detail=exc.message_vi)

    encrypted = encrypt_github_pat(payload.personal_access_token.strip())
    masked = mask_github_pat(payload.personal_access_token.strip())
    conn = db_store.upsert_github_connection(
        user_id=user["id"],
        github_username=profile.github_username,
        encrypted_pat=encrypted,
        masked_pat=masked,
        github_user_id=profile.github_user_id,
        avatar_url=profile.avatar_url,
        scopes=profile.scopes,
        selected_repo_full_name=payload.selected_repo_full_name,
    )
    return {"message": "Kết nối GitHub Personal Access Token thành công.", "github": conn}

@router.post("/reconnect")
def reconnect_github(payload: GitHubConnectRequest, user=Depends(require_csrf)):
    return connect_github(payload, user)

@router.post("/verify")
def verify_github_connection(user=Depends(require_csrf)):
    gh = db_store.get_github_connection(user["id"], include_encrypted=True)
    if not gh:
        raise HTTPException(status_code=404, detail="Chưa kết nối tài khoản GitHub.")
    try:
        pat = decrypt_github_pat(gh["encrypted_pat"])
        profile = github_client.verify_pat_and_get_profile(pat, expected_username=gh["github_username"])
        return {
            "status": "CONNECTED",
            "github_username": profile.github_username,
            "avatar_url": profile.avatar_url,
            "masked_pat": gh["masked_pat"],
            "scopes": profile.scopes,
        }
    except GitHubServiceError as exc:
        raise HTTPException(status_code=exc.status_code, detail=exc.message_vi)

@router.get("/profile")
def get_github_profile(user=Depends(get_current_user)):
    gh = db_store.get_github_connection(user["id"], include_encrypted=False)
    if not gh:
        return {"status": "DISCONNECTED"}
    return gh

@router.get("/repositories")
def list_repositories(user=Depends(get_current_user)):
    gh = db_store.get_github_connection(user["id"], include_encrypted=True)
    if not gh:
        raise HTTPException(status_code=400, detail="Vui lòng kết nối GitHub PAT trước.")
    try:
        pat = decrypt_github_pat(gh["encrypted_pat"])
        repos = github_client.list_user_repositories(pat, gh["github_username"])
        return {"repositories": repos, "selected_repo_full_name": gh.get("selected_repo_full_name")}
    except GitHubServiceError as exc:
        raise HTTPException(status_code=exc.status_code, detail=exc.message_vi)

@router.post("/repositories/create")
def create_repository(payload: CreateRepoRequest, user=Depends(require_csrf)):
    gh = db_store.get_github_connection(user["id"], include_encrypted=True)
    if not gh:
        raise HTTPException(status_code=400, detail="Vui lòng kết nối GitHub PAT trước.")
    try:
        pat = decrypt_github_pat(gh["encrypted_pat"])
        created = github_client.create_private_repository(pat, payload.repo_name, private=payload.private)
        saved = db_store.set_selected_repository(
            user_id=user["id"],
            full_name=created["full_name"],
            repo_name=created["name"],
            private=created["private"],
            default_branch=created["default_branch"],
        )
        return {"message": "Đã tạo và chọn Private Repository thành công.", "repository": saved}
    except GitHubServiceError as exc:
        raise HTTPException(status_code=exc.status_code, detail=exc.message_vi)

@router.post("/repositories/select")
def select_repository(payload: SelectRepoRequest, user=Depends(require_csrf)):
    try:
        repo_name = payload.full_name.split("/")[-1]
        saved = db_store.set_selected_repository(
            user_id=user["id"],
            full_name=payload.full_name,
            repo_name=repo_name,
        )
        return {"message": "Đã chọn Repository cho tiến trình build.", "repository": saved}
    except OwnershipViolationError as exc:
        raise HTTPException(status_code=403, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

@router.delete("/disconnect")
def disconnect_github(user=Depends(require_csrf)):
    db_store.disconnect_github(user["id"])
    return {"message": "Đã ngắt kết nối GitHub và xóa Token khỏi hệ thống.", "status": "DISCONNECTED"}
