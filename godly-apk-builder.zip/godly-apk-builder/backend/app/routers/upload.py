import os
import uuid
from fastapi import APIRouter, UploadFile, File, HTTPException, Depends
from app.config import settings
from app.zip_validator import validate_zip_file, ZipValidationError
from app.database import BuildLockConflictError
from app.deps import db_store, get_current_user, require_csrf

router = APIRouter(prefix="/api/upload", tags=["upload"])

@router.get("/quota")
def get_quota(user=Depends(get_current_user)):
    return db_store.get_upload_quota(user["id"])

@router.post("/zip")
async def upload_zip(file: UploadFile = File(...), user=Depends(require_csrf)):
    if not file.filename:
        raise HTTPException(status_code=400, detail="Tên file ZIP không hợp lệ.")

    user_dir = os.path.join(settings.STORAGE_ROOT, "users", user["id"], "uploads")
    os.makedirs(user_dir, exist_ok=True)
    zip_id = str(uuid.uuid4())
    safe_base = os.path.basename(file.filename.replace("\\", "/"))
    dest_path = os.path.join(user_dir, f"{zip_id}_{safe_base}")

    total_read = 0
    max_bytes = settings.max_upload_bytes
    try:
        with open(dest_path, "wb") as out:
            while True:
                chunk = await file.read(65536)
                if not chunk:
                    break
                total_read += len(chunk)
                if total_read > max_bytes:
                    out.close()
                    if os.path.exists(dest_path):
                        os.remove(dest_path)
                    raise HTTPException(status_code=413, detail=f"Dung lượng file vượt quá giới hạn {settings.MAX_UPLOAD_MB} MB.")
                out.write(chunk)

        meta = validate_zip_file(dest_path, safe_base)
        quota = db_store.record_pending_zip_upload(
            user_id=user["id"],
            zip_id=zip_id,
            zip_name=meta.zip_filename,
            zip_path=dest_path,
            zip_size=meta.file_size,
            zip_sha256=meta.sha256_hex,
            apk_name=meta.apk_filename,
        )
        return {
            "message": "Tải lên và kiểm tra file ZIP thành công.",
            "zip": {
                "zip_id": zip_id,
                "zip_name": meta.zip_filename,
                "apk_name": meta.apk_filename,
                "file_size": meta.file_size,
                "unpacked_size": meta.unpacked_size,
                "entry_count": meta.entry_count,
                "sha256": meta.sha256_hex,
            },
            "quota": quota,
        }
    except ZipValidationError as exc:
        if os.path.exists(dest_path):
            os.remove(dest_path)
        raise HTTPException(status_code=400, detail=exc.message_vi)
    except BuildLockConflictError as exc:
        if os.path.exists(dest_path):
            os.remove(dest_path)
        raise HTTPException(status_code=409, detail=exc.message_vi)
    except PermissionError as exc:
        if os.path.exists(dest_path):
            os.remove(dest_path)
        raise HTTPException(status_code=403, detail=str(exc))

@router.delete("/pending")
def remove_pending_zip(user=Depends(require_csrf)):
    try:
        quota = db_store.remove_pending_zip(user["id"])
        return {"message": "Đã xóa file ZIP đang chờ.", "quota": quota}
    except BuildLockConflictError as exc:
        raise HTTPException(status_code=409, detail=exc.message_vi)
