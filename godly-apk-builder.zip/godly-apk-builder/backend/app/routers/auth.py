import secrets
import hashlib
from fastapi import APIRouter, Request, Response, HTTPException, Depends
from app.config import settings
from app.schemas import (
    RegisterRequest, LoginRequest, ForgotPasswordRequest, ResetPasswordRequest, ChangePasswordRequest
)
from app.database import DatabaseConstraintError
from app.security import (
    hash_password, verify_password, validate_password_strength,
    generate_session_token, generate_csrf_token, hash_session_token,
    login_rate_limiter, register_rate_limiter
)
from app.smtp_service import send_password_reset_email, SmtpConfigurationError
from app.deps import db_store, build_manager, get_current_user, get_current_session, require_csrf, SESSION_COOKIE_NAME

router = APIRouter(prefix="/api/auth", tags=["auth"])

@router.post("/register")
def register(payload: RegisterRequest, request: Request):
    client_ip = request.client.host if request.client else "127.0.0.1"
    allowed, retry_after = register_rate_limiter.check_and_record(f"reg:{client_ip}")
    if not allowed:
        raise HTTPException(status_code=429, detail=f"Quá nhiều yêu cầu đăng ký. Vui lòng thử lại sau {retry_after} giây.")

    if payload.password != payload.confirm_password:
        raise HTTPException(status_code=400, detail="Mật khẩu xác nhận không khớp.")
    if not payload.terms_accepted:
        raise HTTPException(status_code=400, detail="Bạn phải đồng ý với điều khoản sử dụng.")

    ok, msg = validate_password_strength(payload.password)
    if not ok:
        raise HTTPException(status_code=400, detail=msg)

    try:
        pw_hash = hash_password(payload.password)
        user = db_store.create_user(
            username=payload.username,
            email=payload.email,
            password_hash=pw_hash,
            terms_accepted=payload.terms_accepted,
        )
        return {
            "message": "Đăng ký tài khoản thành công.",
            "user": {"id": user["id"], "username": user["username"], "email": user["email"]},
        }
    except DatabaseConstraintError as exc:
        raise HTTPException(status_code=409, detail=str(exc))

@router.post("/login")
def login(payload: LoginRequest, request: Request, response: Response):
    client_ip = request.client.host if request.client else "127.0.0.1"
    rate_key = f"login:{client_ip}:{payload.identifier.lower()}"
    allowed, retry_after = login_rate_limiter.check_and_record(rate_key)
    if not allowed:
        raise HTTPException(status_code=429, detail=f"Tài khoản tạm khóa đăng nhập do thử sai nhiều lần. Thử lại sau {retry_after} giây.")

    user = db_store.get_user_by_identifier(payload.identifier)
    if not user or not verify_password(payload.password, user["password_hash"]):
        raise HTTPException(status_code=401, detail="Tên đăng nhập/email hoặc mật khẩu không chính xác.")

    login_rate_limiter.reset(rate_key)
    raw_token, token_hash = generate_session_token()
    temp_session_id = secrets.token_hex(16)
    csrf_token = generate_csrf_token(temp_session_id)
    session = db_store.create_session(
        user_id=user["id"],
        token_hash=token_hash,
        csrf_token=csrf_token,
        remember_me=payload.remember_me,
        ip_address=client_ip,
        user_agent=request.headers.get("user-agent", ""),
    )
    # Re-bind CSRF token to persisted session id
    bound_csrf = generate_csrf_token(session["id"])
    max_age = (settings.SESSION_REMEMBER_DAYS * 86400) if payload.remember_me else (settings.SESSION_EXPIRE_HOURS * 3600)
    response.set_cookie(
        key=SESSION_COOKIE_NAME,
        value=raw_token,
        httponly=True,
        secure=settings.COOKIE_SECURE,
        samesite=settings.COOKIE_SAMESITE,
        max_age=max_age,
        path="/",
    )
    return {
        "message": "Đăng nhập thành công.",
        "csrf_token": bound_csrf,
        "user": {
            "id": user["id"],
            "username": user["username"],
            "email": user["email"],
            "is_admin": bool(user["is_admin"]),
        },
    }

@router.post("/logout")
def logout(request: Request, response: Response):
    raw_token = request.cookies.get(SESSION_COOKIE_NAME)
    if raw_token:
        db_store.delete_session_by_token_hash(hash_session_token(raw_token))
    response.delete_cookie(key=SESSION_COOKIE_NAME, path="/")
    return {"message": "Đã đăng xuất thành công."}

@router.get("/me")
def get_me(request: Request, user=Depends(get_current_user), session=Depends(get_current_session)):
    gh = db_store.get_github_connection(user["id"], include_encrypted=False)
    quota = db_store.get_upload_quota(user["id"])
    latest_build = build_manager.get_latest_build_for_user(user["id"])
    return {
        "user": {
            "id": user["id"],
            "username": user["username"],
            "email": user["email"],
            "is_admin": bool(user["is_admin"]),
        },
        "csrf_token": generate_csrf_token(session["id"]),
        "github": gh or {"status": "DISCONNECTED"},
        "quota": quota,
        "active_or_latest_build": latest_build,
    }

@router.post("/forgot-password")
def forgot_password(payload: ForgotPasswordRequest):
    user = db_store.get_user_by_identifier(payload.email)
    if not user:
        return {"message": "Nếu email tồn tại trong hệ thống, hướng dẫn đặt lại mật khẩu đã được gửi qua SMTP."}
    raw_reset = secrets.token_urlsafe(32)
    reset_hash = hashlib.sha256(raw_reset.encode("utf-8")).hexdigest()
    db_store.set_password_reset_token(user["id"], reset_hash, expires_minutes=30)
    try:
        send_password_reset_email(user["email"], user["username"], raw_reset)
    except SmtpConfigurationError as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    return {"message": "Email đặt lại mật khẩu đã được gửi qua máy chủ SMTP."}

@router.post("/reset-password")
def reset_password(payload: ResetPasswordRequest):
    if payload.new_password != payload.confirm_password:
        raise HTTPException(status_code=400, detail="Mật khẩu xác nhận không khớp.")
    ok, msg = validate_password_strength(payload.new_password)
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    token_hash = hashlib.sha256(payload.token.encode("utf-8")).hexdigest()
    user = db_store.get_user_by_reset_token_hash(token_hash)
    if not user:
        raise HTTPException(status_code=400, detail="Token đặt lại mật khẩu không hợp lệ hoặc đã hết hạn.")
    db_store.update_user_password(user["id"], hash_password(payload.new_password))
    return {"message": "Đặt lại mật khẩu thành công. Vui lòng đăng nhập lại."}

@router.post("/change-password")
def change_password(payload: ChangePasswordRequest, user=Depends(require_csrf)):
    if not verify_password(payload.current_password, user["password_hash"]):
        raise HTTPException(status_code=400, detail="Mật khẩu hiện tại không chính xác.")
    if payload.new_password != payload.confirm_password:
        raise HTTPException(status_code=400, detail="Mật khẩu mới và xác nhận không khớp.")
    ok, msg = validate_password_strength(payload.new_password)
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    db_store.update_user_password(user["id"], hash_password(payload.new_password))
    return {"message": "Đổi mật khẩu thành công."}
