import os
import sys
import shutil
import tempfile
import unittest
import zipfile

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.crypto import encrypt_github_pat, decrypt_github_pat, mask_github_pat, TokenCryptoError
from app.security import (
    hash_password, verify_password, validate_password_strength,
    generate_csrf_token, verify_csrf_token, mask_secrets_in_text, RateLimiter
)
from app.zip_validator import (
    derive_apk_name_from_zip, validate_zip_file, extract_zip_safely, ZipValidationError
)
from app.android_detector import detect_android_project, find_and_verify_built_apk, AndroidProjectError
from app.database import DatabaseStore, DatabaseConstraintError, BuildLockConflictError, OwnershipViolationError
from app.build_lock import BuildEngineManager
from app.github_service import GitHubClient, GitHubServiceError
from app.error_analyzer import analyze_build_failure

class GodlyApkBuilderFullTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.mkdtemp(prefix="godly_test_")
        self.db = DatabaseStore(sqlite_path=":memory:")
        self.engine = BuildEngineManager(self.db)

    def tearDown(self):
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def _create_valid_android_zip(self, zip_name="Claude.zip", nested_prefix="outer_folder/inner_project"):
        zp = os.path.join(self.temp_dir, zip_name)
        with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.writestr(f"{nested_prefix}/settings.gradle.kts", 'rootProject.name = "ClaudeApp"\ninclude(":app")\n')
            zf.writestr(f"{nested_prefix}/build.gradle.kts", '// Top-level build file\n')
            zf.writestr(
                f"{nested_prefix}/app/build.gradle.kts",
                'plugins { id("com.android.application") }\nandroid { defaultConfig { versionName = "2.4.0" } }\n'
            )
            zf.writestr(f"{nested_prefix}/app/src/main/AndroidManifest.xml", '<manifest package="com.godly.app"/>')
        return zp

    def _create_real_apk_file(self, directory, filename="app-debug.apk"):
        os.makedirs(directory, exist_ok=True)
        apk_p = os.path.join(directory, filename)
        with zipfile.ZipFile(apk_p, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.writestr("AndroidManifest.xml", "<manifest/>" + ("A" * 1024))
            zf.writestr("classes.dex", "DEX_DATA_" + ("B" * 2048))
        return apk_p

    def test_01_password_hashing_and_csrf_and_rate_limit(self):
        pw = "GodlySecure2026"
        ok, _ = validate_password_strength(pw)
        self.assertTrue(ok)
        hashed = hash_password(pw)
        self.assertNotEqual(pw, hashed)
        self.assertTrue(verify_password(pw, hashed))
        self.assertFalse(verify_password("WrongPass123", hashed))

        csrf = generate_csrf_token("sess-123")
        self.assertTrue(verify_csrf_token("sess-123", csrf))
        self.assertFalse(verify_csrf_token("sess-999", csrf))

        limiter = RateLimiter(max_attempts=2, window_seconds=60)
        self.assertTrue(limiter.check_and_record("ip1")[0])
        self.assertTrue(limiter.check_and_record("ip1")[0])
        self.assertFalse(limiter.check_and_record("ip1")[0])

    def test_02_aes_256_gcm_token_encryption_and_masking(self):
        raw_pat = "ghp_1234567890abcdef1234567890abcdef9x2a"
        enc = encrypt_github_pat(raw_pat)
        self.assertNotIn(raw_pat, enc)
        dec = decrypt_github_pat(enc)
        self.assertEqual(raw_pat, dec)
        masked = mask_github_pat(raw_pat)
        self.assertTrue(masked.startswith("ghp_"))
        self.assertTrue(masked.endswith("9x2a"))
        self.assertNotIn("1234567890abcdef", masked)

        log_txt = f"Error calling API with {raw_pat} and Authorization: Bearer {raw_pat}"
        scrubbed = mask_secrets_in_text(log_txt)
        self.assertNotIn(raw_pat, scrubbed)

    def test_03_zip_validation_zip_slip_zip0_and_dynamic_apk_naming(self):
        self.assertEqual(derive_apk_name_from_zip("Claude.zip"), "Claude.apk")
        self.assertEqual(derive_apk_name_from_zip("Moon.zip"), "Moon.apk")

        # Reject static ZIP 0
        z0 = self._create_valid_android_zip("SampleZeroApp.zip")
        with self.assertRaises(ZipValidationError):
            validate_zip_file(z0, "SampleZeroApp.zip")

        # Reject Zip Slip path traversal
        slip_zip = os.path.join(self.temp_dir, "evil.zip")
        with zipfile.ZipFile(slip_zip, "w") as zf:
            zf.writestr("../../etc/passwd", "root:x:0:0")
        with self.assertRaises(ZipValidationError):
            validate_zip_file(slip_zip, "evil.zip")

    def test_04_nested_android_detection_and_real_apk_verification(self):
        zp = self._create_valid_android_zip("Moon.zip", nested_prefix="wrapper1/wrapper2/android_proj")
        ext_dir = os.path.join(self.temp_dir, "extracted")
        meta = extract_zip_safely(zp, ext_dir, "Moon.zip")
        self.assertEqual(meta.apk_filename, "Moon.apk")

        detected = detect_android_project(ext_dir)
        self.assertEqual(detected.app_module, "app")
        self.assertTrue(detected.android_root.endswith("android_proj"))

        # Without APK -> must raise ARTIFACT_MISSING
        with self.assertRaises(AndroidProjectError) as ctx:
            find_and_verify_built_apk(detected.android_root, "app", "Moon.apk")
        self.assertEqual(ctx.exception.code, "ARTIFACT_MISSING")

        # Create real APK in outputs/apk/debug
        apk_out_dir = os.path.join(detected.android_root, "app", "build", "outputs", "apk", "debug")
        self._create_real_apk_file(apk_out_dir, "app-debug.apk")
        verified = find_and_verify_built_apk(detected.android_root, "app", "Moon.apk")
        self.assertEqual(verified.apk_name, "Moon.apk")
        self.assertEqual(verified.version_name, "2.4.0")

    def test_05_user_isolation_build_lock_quota_and_lifecycle(self):
        u1 = self.db.create_user("alice", "alice@example.com", hash_password("AlicePass123"))
        u2 = self.db.create_user("bob", "bob@example.com", hash_password("BobPass123"))

        # Connect GitHub for Alice & Bob
        self.db.upsert_github_connection(
            u1["id"], "alice-gh", encrypt_github_pat("ghp_alice_secret_token_123456"), "ghp_••••3456",
            selected_repo_full_name="alice-gh/apk-builder"
        )
        self.db.upsert_github_connection(
            u2["id"], "bob-gh", encrypt_github_pat("ghp_bob_secret_token_654321"), "ghp_••••4321",
            selected_repo_full_name="bob-gh/apk-builder"
        )

        zp = self._create_valid_android_zip("Claude.zip")
        meta = validate_zip_file(zp, "Claude.zip")
        q1 = self.db.record_pending_zip_upload(
            u1["id"], "zip-1", meta.zip_filename, zp, meta.file_size, meta.sha256_hex, meta.apk_filename
        )
        self.assertEqual(q1["remaining_uploads"], 9)

        # Start build 1 for Alice
        b1 = self.engine.start_build_atomic(u1["id"])
        self.assertEqual(b1["status"], "QUEUED")
        self.assertEqual(b1["apk_name"], "Claude.apk")
        self.assertTrue(b1["is_locked"])

        # Concurrent/duplicate build for Alice MUST fail with BuildLockConflictError
        with self.assertRaises(BuildLockConflictError):
            self.engine.start_build_atomic(u1["id"])

        # Replacing ZIP while build is locked MUST fail
        with self.assertRaises(BuildLockConflictError):
            self.db.record_pending_zip_upload(
                u1["id"], "zip-2", meta.zip_filename, zp, meta.file_size, meta.sha256_hex, meta.apk_filename
            )

        # Cross-user IDOR check: Bob cannot view or cancel Alice's build
        with self.assertRaises(OwnershipViolationError):
            self.engine.get_build_status(u2["id"], b1["build_id"])
        with self.assertRaises(OwnershipViolationError):
            self.engine.cancel_build(u2["id"], b1["build_id"])

        # Complete Alice's build with a verified real APK
        real_apk = self._create_real_apk_file(self.temp_dir, "Claude.apk")
        done = self.engine.complete_build_with_verified_apk(
            b1["build_id"], real_apk, os.path.getsize(real_apk), "sha256_dummy", "1.0-debug"
        )
        self.assertEqual(done["status"], "SUCCESS")
        self.assertEqual(done["progress_percent"], 100)
        self.assertFalse(done["is_locked"])
        self.assertTrue(done["artifact_available"])

        # Bob cannot download Alice's APK
        with self.assertRaises(OwnershipViolationError):
            self.engine.get_verified_artifact_for_download(u2["id"], b1["build_id"])

    def test_06_error_analyzer_14_categories_and_github_mock_transport(self):
        err = analyze_build_failure("ERROR_CODE=MISSING_SETTINGS_GRADLE|Missing settings.gradle")
        self.assertEqual(err.error_code, "MISSING_SETTINGS_GRADLE")
        self.assertIn("settings.gradle", err.category_vi)

        # Test GitHubClient invalid/revoked token handling
        def fake_401(method, url, headers, body, timeout):
            return 401, {}, b'{"message": "Bad credentials"}'

        gh_client = GitHubClient(transport=fake_401)
        with self.assertRaises(GitHubServiceError) as ctx:
            gh_client.verify_pat_and_get_profile("ghp_revoked_token_1234567890")
        self.assertEqual(ctx.exception.code, "GITHUB_TOKEN_INVALID")

if __name__ == "__main__":
    unittest.main()
