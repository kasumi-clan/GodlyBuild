# Godly APK Builder — Production Android APK Cloud Compiler

Build Android debug APKs directly from a `.zip` archive using your own GitHub account and GitHub Actions — accessible on phones, tablets, and desktops without Android Studio.

---

## 1. Cài đặt (Installation)
```bash
git clone <your-repo-url> godly-apk-builder
cd godly-apk-builder
cp .env.example .env
```

## 2. Cấu hình Environment (`.env`)
Chỉnh sửa file `.env` từ mẫu `.env.example` (tuyệt đối không commit `.env` thật lên Git):
- `FRONTEND_URL`: URL chạy giao diện frontend (ví dụ `http://localhost:5173`).
- `BACKEND_URL`: URL chạy FastAPI backend (ví dụ `http://localhost:8000`).
- `MAX_UPLOAD_MB=25`, `DEFAULT_UPLOAD_QUOTA=10`, `QUOTA_RESET_POLICY=manual`.

## 3. Cấu hình Database (PostgreSQL & Alembic)
```bash
cd backend
pip install -r requirements.txt
alembic upgrade head
```

## 4. Cấu hình Encryption Key (AES-256-GCM)
Tạo khóa `ENCRYPTION_MASTER_KEY` 32-byte (64 ký tự hex) để mã hóa GitHub Personal Access Token:
```bash
python3 -c "import secrets; print(secrets.token_hex(32))"
```

## 5. Cấu hình SMTP (Khôi phục mật khẩu thật)
Điền thông tin máy chủ SMTP thực tế vào `.env`:
- `SMTP_HOST`, `SMTP_PORT`, `SMTP_USE_TLS`, `SMTP_USER`, `SMTP_PASSWORD`, `SMTP_FROM_EMAIL`.

## 6. Tạo GitHub Personal Access Token (PAT)
Truy cập **GitHub Settings → Developer settings → Personal access tokens**.

## 7. GitHub Permissions (Quyền tối thiểu - Least Privilege)
- **Classic PAT**: Chỉ chọn quyền `repo` và `workflow`.
- **Fine-grained PAT**: Chỉ chọn repository dùng để build với quyền `Contents: Read and Write` và `Actions: Read and Write`.

## 8. Kết nối GitHub trên Website
Đăng nhập vào tài khoản Godly APK Builder → Nhấn nút **Kết nối GitHub** trên Header → Nhập GitHub Username và PAT → Chọn Repository hoặc nhấn **Tạo Private Repo**.

## 9. Build APK
Tải lên file `.zip` chứa dự án Android (`ZIP 1`, tối đa 25 MB) → Nhấn **TẠO APK** → Theo dõi 6 bước tiến trình thực tế trên khung màu xanh đậm Navy. Tên APK tự động lấy theo tên file ZIP (`Claude.zip` → `Claude.apk`, `Moon.zip` → `Moon.apk`).

## 10. Download APK
Khi tiến trình đạt `100% SUCCESS` và xác thực có file APK thật, thẻ **TẢI APK** tự động xuất hiện bên dưới. Nhấn **TẢI APK** để tải về máy.

## 11. Deploy Website (Docker Compose)
```bash
docker compose up -d --build
```

## 12. Troubleshooting (Xử lý sự cố)
- **Thiếu `settings.gradle`**: Đảm bảo trong file ZIP có `settings.gradle` hoặc `settings.gradle.kts`.
- **Token báo `401/403`**: Mở cửa sổ kết nối GitHub, cấp lại PAT có quyền `repo` + `workflow` và nhấn **Reconnect**.
